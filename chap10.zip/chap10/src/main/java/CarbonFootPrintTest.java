/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class CarbonFootPrintTest {
    public static void main(String [] args){
        CarbonFootPrint[] carbonObjects = new CarbonFootPrint[]{
            new Bike(30,33),
            new Building(500,11.7),
            new Car(2500,400)};
        
        for(CarbonFootPrint carbon : carbonObjects){
            System.out.printf("%s%n",carbon.toString());
        }
    }
}
