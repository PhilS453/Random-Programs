/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class ShapesTest {
    public static void  main(String[] args){
//        Square mySquare = new Square(5,5);
//        Triangle myTriangle = new Triangle(5,5,10);
//        System.out.print(mySquare);
//        System.out.println();
//        Cube myCube = new Cube(5,5,5);
//        System.out.print(myCube);
//        System.out.println();
//        System.out.print(myTriangle);
        Shape[] shapes = new Shape[]{
            new Triangle(5,5,5),
            new Square(5,6),
            new Cube(5,5,5),
            new RectangularPrism(6,6,10)};
        
        for (Shape shape : shapes) {
            System.out.print(shape);
            System.out.println();
        }
    }
}

