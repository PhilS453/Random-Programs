/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class BasePlusCommissionEmployee extends CommissionEmployee {
    private double baseSalary;
    public BasePlusCommissionEmployee(String firstName,String lastName,String social,int birthday,
            double grossSales,double commissionRate,double baseSalary){
        super(firstName,lastName,social,birthday,grossSales,commissionRate);
        
        if (baseSalary < 0.0){
            throw new IllegalArgumentException("Salary must be >= 0");
        }
        this.baseSalary = baseSalary;
    }
    
    public void setBaseSalary(double baseSalary){
        if (baseSalary < 0.0){
            throw new IllegalArgumentException("Salary must be >= 0");
        }
        this.baseSalary = baseSalary;
    }
    public double getBaseSalary(){return baseSalary;};
    
    @Override
    public double earnings(){return getBaseSalary() + super.earnings();};
    
    @Override
    public String toString(){
        return String.format("%s %s; %s; $%,.2f",
                "base-salaried",super.toString(),
                "base-salary",getBaseSalary());
    }
}
