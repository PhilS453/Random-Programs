/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class PieceWorker extends employee{
    private double wage;
    private double pieces;
    
    public PieceWorker(String firstName, String lastName, String social,int birthday,
            double wage,double pieces){
        super(firstName,lastName,social,birthday);
        
        if(wage <= 0){
            throw new IllegalArgumentException("Wage must be > 0.0");
        }
        if(pieces <= 0.0){
            throw new IllegalArgumentException("Pieces must be > 0.0");
        }
        this.wage = wage;
        this.pieces = pieces;
    }
    
    public void setWage(double wage){
        if(wage <= 0){
            throw new IllegalArgumentException("Wage must be > 0.0");
        }
        this.wage = wage;
    }
    
    public void setPieces(double pieces){
        if(pieces <= 0.0){
            throw new IllegalArgumentException("Pieces must be > 0.0");
        }
        this.pieces = pieces;
    }
    
    public double getWage(){return wage;};
    public double getPieces(){return pieces;};
    
    
    @Override
    public double earnings(){
        return getWage() * getPieces();
    }
    
    @Override
    public String toString(){
        return String.format("Piece-wage employee: %s%n%s%s%n%s%s",
                super.toString(),"Wages:",getWage(),"Pieces:",
                getPieces());
    }
}
