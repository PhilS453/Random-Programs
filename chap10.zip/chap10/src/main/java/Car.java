/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Car implements CarbonFootPrint{
    private int yearlyMileage;
    private final double multiplier;
    
    public Car(int yearlyMileage,double multiplier){
        this.yearlyMileage= yearlyMileage;
        this.multiplier = multiplier;
    }

    public double getMultiplier() {
        return multiplier;
    }

    public int getYearlyMileage() {
        return yearlyMileage;
    }

    public void setYearlyMileage(int yearlyMileage) {
        this.yearlyMileage = yearlyMileage;
    }
    
    @Override
    public double getCarbonFootPrint(){
        return yearlyMileage * multiplier;
    }
    @Override
    public String toString(){
        return String.format("""
                             A cars yearly mileage multipllied by an emission factor yields the carbon footprint of the vehicle
                             this cars carbon footprint is: %.2f%s""",getCarbonFootPrint(),"grams of CO2 for the day");
    }
}
