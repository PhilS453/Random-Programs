/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public abstract class TwoDimensional implements Shape{
    private double length;
    private double height;
    
    public TwoDimensional(double length,double height){
        this.length = length;
        this.height = height;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }
    
    public abstract double getArea();
    
    @Override
    public String toString(){
        return String.format("%s",getType());
    }
    @Override
    public String getType(){
        return "Two Dimensional";
    }
}
