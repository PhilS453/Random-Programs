/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class SalariedEmployee extends employee{
    private double weeklySalary;
    
    public SalariedEmployee(String firstName,String lastName,String social, int birthday,
            double weeklySalary){
        super(firstName,lastName,social,birthday);
        
        if(weeklySalary < 0.0){
            throw new IllegalArgumentException(
            "Weekly Salary must be >= 0.0");
        }
        this.weeklySalary = weeklySalary;
    }
    
    public void setWeeklySalary(double weeklySalary){
        if(weeklySalary < 0.0){
            throw new IllegalArgumentException(
            "Weekly Salary must be >= 0.0");
        }
        this.weeklySalary = weeklySalary;
    }
    
    public double getWeeklySalary(){return weeklySalary;};
    
    @Override
    public double earnings(){return getWeeklySalary();};
    
    @Override
    public String toString(){
        return String.format("Salaried Employee : %s%n%s: $%,.2f",
                super.toString(),"Weekly Salary",getWeeklySalary());
    }
}
