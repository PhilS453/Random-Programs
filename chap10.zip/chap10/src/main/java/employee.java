/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public  abstract class employee {
    private final String firstName;
    private final String lastName;
    private final String social;
    private int birthday;
    
    public employee(String firstName,String lastName, String social,int birthday){
        this.firstName = firstName;
        this.lastName = lastName;
        this.social = social;
        this.birthday = birthday;
    }
    
    public String getFirstName(){return firstName;};
    
    public String getLastName(){return lastName;};
    
    public String getSocial(){return social;};
    
    public int getDate(){return birthday;};
    
    @Override
    public String toString(){
        return String.format("%s %s %nbirthmonth: %s%nsocial security number: %s",
                getFirstName(),getLastName(),getDate(),getSocial());
    }
    
    public abstract double earnings();
}
