/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Square extends TwoDimensional {
    public Square(double length,double height){
        super(length,height);
    }
    
    @Override
    public double getArea(){
        return super.getLength() * super.getLength();
    }
    @Override
    public String toString(){
        return String.format("%s:%s%.2f", super.toString()," Square with area:  ",
                getArea());
    }
}
