/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Building implements CarbonFootPrint {
    private int naturalGasBill;
    private final double multiplier;
    
    public Building( int naturalGasBill,double multiplier){
        this.naturalGasBill = naturalGasBill;
        this.multiplier = multiplier;
    }

    public double getMultiplier() {
        return multiplier;
    }

    public int getNaturalGasBill() {
        return naturalGasBill;
    }

    public void setNaturalGasBill(int naturalGasBill) {
        this.naturalGasBill = naturalGasBill;
    }
    @Override
    public double getCarbonFootPrint(){
        return naturalGasBill * multiplier;
    }
    @Override
    public String toString(){
        return String.format("""
                             A buildings carbon footprint is their total of natural gas multiplied by 11.7
                             This buildings footprint is: %s%s""",getCarbonFootPrint(),"lbs of CO2 emissions!");
    }
    
}
