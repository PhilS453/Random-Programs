/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Bike implements CarbonFootPrint {
    private double milesTraveled;
    private double gramsCO2;
    
    
    public Bike(double milesTraveled,double gramsCO2){
        this.milesTraveled = milesTraveled;
        this.gramsCO2 = gramsCO2;
    }

    public double getGramsCO2() {
        return gramsCO2;
    }

    public void setGramsCO2(int gramsCO2) {
        this.gramsCO2 = gramsCO2;
    }

    public double getMilesTraveled() {
        return milesTraveled;
    }

    public void setMilesTraveled(int milesTraveled) {
        this.milesTraveled = milesTraveled;
    }
    
    @Override
    public double getCarbonFootPrint(){
        return getMilesTraveled() * getGramsCO2();
    }
    
    @Override
    public String toString(){
        return String.format("""
                             Carboon footprint for bike is calculate by a constant multiplied by the miles that the bike was ridden
                             the bikes carbon footprint is:  %s grams of CO2""",getCarbonFootPrint());
    }
}
