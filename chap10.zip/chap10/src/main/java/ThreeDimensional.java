/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public abstract class ThreeDimensional implements Shape {
    private double length;
    private double height;
    private double width;
    
    public ThreeDimensional(double length,double height,double width){
        this.length = length;
        this.height = height;
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }
    
    public abstract double getArea();
    public abstract double getVolume();
    
    @Override
    public String getType(){
        return "Three Dimensional ";
    }
    @Override
    public String toString(){
        return String.format("%s",getType());
    }

}
