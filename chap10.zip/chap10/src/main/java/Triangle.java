/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Triangle extends TwoDimensional {
    private double base;
    public Triangle(double length,double height,double base){
        super(length,height);
        
        
        this.base = base;
    }
    
    @Override
    public double getArea(){
        return .5 * base * super.getHeight();
    }
    @Override
    public String toString(){
        return String.format("%s:%s%.2f", super.toString()," Triangle with area:  ",
                getArea());
    }
}
