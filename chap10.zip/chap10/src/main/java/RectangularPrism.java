/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class RectangularPrism extends ThreeDimensional {
    public RectangularPrism(double length,double width,double height){
        super(length,width,height);
    }
    
    @Override
    public double getArea(){
        return 2*((super.getWidth()*super.getLength())+(super.getHeight()*super.getWidth())+
        (super.getHeight()*super.getWidth()));
    }
    @Override
    public double getVolume(){
        return super.getLength()*super.getWidth()*super.getHeight();
    }
    @Override
    public String toString(){
        return String.format("%s:%s%.2f%s%.2f", super.toString()," Rectangular Prism with area:  ",
                getArea()," And with volume: ",getVolume());
    }
}
