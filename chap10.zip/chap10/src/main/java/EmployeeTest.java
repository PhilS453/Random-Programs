/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class EmployeeTest {
    public static void main(String[]args){
        SalariedEmployee salariedEmployee = new
        SalariedEmployee("John","Smith","111-11-1111",1,800.00);
        HourlyEmployee hourlyEmployee = new HourlyEmployee("Karen","Price","222-22-2222",1,
                16.75,40);
        CommissionEmployee commishEmployee = new CommissionEmployee("Sue","Jones","333-33-3333",7,
        10000,.06);
        BasePlusCommissionEmployee baseCommishEmployee = new BasePlusCommissionEmployee(
        "Bob","Lewis","444-44-4444",8,5000,.04,300);
        PieceWorker pieceWorkEmployee = new PieceWorker("Amanda","Seros","123-45-678",9,30.00,20);
        
        employee[] employees = new employee[5];
        
        employees[0] = salariedEmployee;
        employees[1]=hourlyEmployee;
        employees[2]=commishEmployee;
        employees[3]=baseCommishEmployee;
        employees[4]=pieceWorkEmployee;
        
        for(employee currentEmployee : employees){
            System.out.println(currentEmployee);
            if(currentEmployee instanceof BasePlusCommissionEmployee){
                BasePlusCommissionEmployee Employee =
                        (BasePlusCommissionEmployee) currentEmployee;
                Employee.setBaseSalary(1.10* Employee.getBaseSalary());
                System.out.printf("new base salary with 10%% increase is: $%,.2f%n",Employee.getBaseSalary());
            }
            System.out.printf(
            "earned $%,.2f%n%n", currentEmployee.earnings());
        }
        
        for(int k = 0; k<6;k++){
            for(int i = 0; i< employees.length;i++){
                if(employees[i].getDate() == k+1){
                    System.out.printf("Bonus recieved-- New earnings employee for "+employees[i].getClass().getName()+"\n%.2f%n",
                        (employees[i].earnings() + 100));
                }
            }
//            if(employees[k].getDate() == k+1){
//                System.out.printf("Bonus recieved-- New earnings employee for "+employees[k].getClass().getName()+"\n%.2f%n",
//                        (employees[k].earnings() + 100));
//            }
        }
        
        for(int j = 0; j< employees.length;j++){
            System.out.printf("Employee %d is a %s%n",j,
                    employees[j].getClass().getName());
        }
        
        
        
        
        
        
    }
}
