/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example711 {
    public static void main(String [] args){
        int [] counts = new int[10];
        for(int i = 0;i<counts.length;i++){
            counts[i]=0;
        }
        System.out.print("Data in Counts: \n");
        for(int i = 0;i<counts.length;i++){
            System.out.printf("%2d",counts[i]);
        }
        int [] bonus = new int[15];
        System.out.println();
        for(int i = 0;i<bonus.length;i++){
            ++bonus[i];
        }
        System.out.print("Data in bonus: \n");
        for(int i = 0;i<bonus.length;i++){
            System.out.printf("%2d",bonus[i]);
            //System.out.print(" ");
        }
        System.out.println();
        int bestScores[] = {5,20,34,56,78};
        System.out.print("Best scores in order they were entered:\n");
        for(int i = 0;i<bestScores.length;i++){
            System.out.printf("%d %n",bestScores[i]);
        }
    }
}
