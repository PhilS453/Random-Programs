import java.util.ArrayList;
import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example712 {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        ArrayList<String> list = new ArrayList<String>();
        list.trimToSize();
        System.out.print("LIST SIZE AT 1 ONCE INPUT IS RECIEVED\n");
        for(int i = 0;i<5;i++){
            System.out.print("Numbers already in the list will not be added!!!");
            System.out.print("Enter an integer to add it to the list\n");
            String numEntered = cin.next();
            if(list.contains(numEntered)){
                continue;
            }
            else{
                list.add(numEntered);
            }
            System.out.print("User Entered: "+numEntered+"\n");
            
        }
        System.out.print("Here was the list that was created:\n");
        for(int i = 0;i<list.size();i++){
            System.out.print(list.get(i));
            System.out.print(" ");
        }
        
        
        
        
    }
}
