import java.security.SecureRandom;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example717 {
    private static final SecureRandom dieRoll = new SecureRandom();
    public static void main(String[]args){
        int [] DieRolls = new int [11] ;
        
        for(int i =0;i<60000000;i++){
            int firstRoll = 1 + dieRoll.nextInt(6);
            int secondRoll = 1 + dieRoll.nextInt(6);
            switch (firstRoll + secondRoll) {
                case 2:
                    ++DieRolls[0];
                    break;
                case 3:
                    ++DieRolls[1];
                    break;
                case 4:
                    ++DieRolls[2];
                    break;
                case 5:
                    ++DieRolls[3];
                    break;
                case 6:
                    ++DieRolls[4];
                    break;
                case 7:
                    ++DieRolls[5];
                    break;
                case 8:
                    ++DieRolls[6];
                    break;
                case 9:
                    ++DieRolls[7];
                    break;
                case 10:
                    ++DieRolls[8];
                    break;
                case 11:
                    ++DieRolls[9];
                    break;
                case 12:
                    ++DieRolls[10];
                    break;
                default:
                    break;
            }
            
        }
        String [] rolls = {"2: ","3: ","4: ","5: ","6: ",
            "7: ","8: ","9: ","10: ","11: ","12: "};
        System.out.print("Based on 60 million rolls: \n");
        System.out.print("-------------------\n");
        for(int i =0;i<11;i++){
            System.out.print(rolls[i]+DieRolls[i]);
            System.out.println();
        }
    
        
        
        
        
    }
}
