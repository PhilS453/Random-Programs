/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example7166 {
    public static void main(String[]args){
        double total = 0.0;
        int num1 = Integer.parseInt(args[0]);
        double[] numbers = new double [num1];
        double num2 = Double.parseDouble(args[1]);
        double num3 = Double.parseDouble(args[2]);
        for(double number : numbers){
            total=total + num3;
        }
        System.out.printf("%.2f",total);
    }
}

