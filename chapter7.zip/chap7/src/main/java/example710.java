/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example710 {
    public static void main(String [] args){
        String[] data = {"$200-$299)","$300-$399)","$400-$499)",
            "$500-$599)","$600-$699)","$700-$799)","$800-$899)",
            "$900-$999)","$1000+)"};
        int[] employeePay =
        {202,589,1001,23,455,678,898,924,1003,456,679,345};
        int[] frequency = new int[9];
        for(int i=0; i<employeePay.length; i++){
            if(employeePay[i]>999){
                ++frequency[8];
            }
            else if(employeePay[i]>899){
                ++frequency[7];
            }
            else if(employeePay[i]>799){
                ++frequency[6];
            }
            else if(employeePay[i]>699){
                ++frequency[5];
            }
            else if(employeePay[i]>599){
                ++frequency[4];
            }
            else if(employeePay[i]>499){
                ++frequency[3];
            }
            else if(employeePay[i]>399){
                ++frequency[2];
            }
            else if(employeePay[i]>299){
                ++frequency[1];
            }
            else{
                ++frequency[0];
            }
            
        }
        System.out.print("Employee Pay");
        System.out.print("\n------------\n");
        for(int i = 0; i<frequency.length;i++){
            System.out.print(data[i]);
            System.out.print(frequency[i]);
            System.out.println();   
            //System.out.println();
        }
    }
}