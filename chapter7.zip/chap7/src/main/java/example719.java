import java.util.Arrays;
import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example719 {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        boolean [] seats = new boolean [10];
        Arrays.fill(seats, false);
        while(true){
            System.out.print("\nPress 1 for First Class and 2 for economy! 3 to quit: ");
            int answer = cin.nextInt();
            if(answer == 1){
                for(int i = 0; i<(5);i++){
                    if((seats[0]==true)&&(seats[1]==true)&&(seats[2]==true)&&(seats[3]==true)&&(seats[4]==true)){
                        System.out.print("Would you like to travel economy?\n");
                        System.out.print("Enter 1 for yes and 2 for no:");
                        int answer2 = cin.nextInt();
                        if(answer2 == 1){
                            for(int j =5;j<10;j++){
                                if(seats[j] == false){
                                seats[j] = true;
                                int seatNum = j+1;
                                System.out.print("BOARDING PASS:\n");
                                System.out.print("You have been assigned seat: "+seatNum);
                                System.out.print("\nENJOY YOUR FLIGHT!");
                                break;
                                }
                            }
                        }
                        else{
                            System.out.print("Next flight is in 3 hours!");
                        }
                    }
                    if(seats[i] == true){
                        continue;
                    }
                    if(seats[i] == false){
                        seats[i] = true;
                        int seatNum = i+1;
                        System.out.print("BOARDING PASS:\n");
                        System.out.print("You have been assigned seat: "+seatNum);
                        System.out.print("\nENJOY YOUR FLIGHT");
                        break;
                    }
                }
            }
            else if(answer == 2){
                for(int i = 5; i<10;i++){
                    if((seats[5]==true)&&(seats[6]==true)&&(seats[7]==true)&&(seats[8]==true)&&(seats[9])==true){
                        System.out.print("Would you like to travel First Class?\n");
                        System.out.print("Enter 1 for yes and 2 for no:");
                        int answer2 = cin.nextInt();
                        if(answer2 == 1){
                            for(int j =0;j<5;j++){
                                if(seats[j] == false){
                                seats[j] = true;
                                int seatNum = j+1;
                                System.out.print("BOARDING PASS:\n");
                                System.out.print("You have been assigned seat: "+seatNum);
                                System.out.print("\nENJOY YOUR FLIGHT");
                                break;
                                }
                            }
                            break;
                        }
                        else{
                            System.out.print("Next flight is in 3 hours!");
                            break;
                        }
                    }
                    if (seats[i] == true){
                        continue;
                    }
                    if(seats[i] == false){
                        seats[i] = true;
                        int seatNum = i+1;
                        System.out.print("BOARDING PASS:\n");
                        System.out.print("You have been assigned seat: "+seatNum);
                        System.out.print("\nENJOY YOUR FLIGHT");
                        break;
                    }
                   
                }
            }
            else{
                break;
            }
        }
        
        
      
        
        
        
        
        
        
        
        
        
        
        
    }
}
