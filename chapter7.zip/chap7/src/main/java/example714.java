/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example714 {
    public static void main(String [] args){
        System.out.print("FACTORIAL USING LISTS!\n");
        int nums [] = {1,2,3,4,5,6,7,8,9,10};
        System.out.print(product(nums));
    }
    
    
    
    
    
    
    
    
    
    
    
    
    public static int product (int...b ){
        int total = 1;
        for(int i = 0;i<b.length;i++){
            total*=b[i];
            
        }
        return total;
    }
}
