/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class InitArray {
    public static void main(String[] args){
        int arrayLength = Integer.parseInt(args[0]);
        if(arrayLength == 0){
            int[] array = new int[10];
            int initialValue = Integer.parseInt(args[1]);
            int increment = Integer.parseInt(args[2]);
            
            for(int counter =0;counter < array.length;counter++){
                array[counter] = initialValue+increment*counter;
            }
            
            System.out.printf("%s%8s%n","Index","Value");
            
            for(int counter = 0; counter < array.length;counter++){
                System.out.printf("%5d%8d%n",counter,array[counter]);
            }
        }
        if(args.length!=3){
            System.out.printf(
            "ERROR: please re-enter the entire command, including %n"+
                    "an array size, initial value and increment.%n");
        }
        else{
            arrayLength = Integer.parseInt(args[0]);
            int[] array = new int[arrayLength];
            
            int initialValue = Integer.parseInt(args[1]);
            int increment = Integer.parseInt(args[2]);
            
            for(int counter =0;counter < array.length;counter++){
                array[counter] = initialValue+increment*counter;
            }
            
            System.out.printf("%s%8s%n","Index","Value");
            
            for(int counter = 0; counter < array.length;counter++){
                System.out.printf("%5d%8d%n",counter,array[counter]);
            }
        }
    }
}
