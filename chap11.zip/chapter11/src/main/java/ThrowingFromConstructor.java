/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class ThrowingFromConstructor  {
    private int length;
    private int width;
    public ThrowingFromConstructor(int length,int width) throws NegativeException{
        try{
            if(length < 0 || width < 0){
                throw new NegativeException(
                "Error one or more of the parameters are negative!");
            }
            this.length = length;
            this.width = width;
        }
        catch(NegativeException e){
            System.out.print(e.getMessage());
        }
        
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }
}
