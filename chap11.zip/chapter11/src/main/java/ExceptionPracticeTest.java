import java.util.Scanner;
import java.util.InputMismatchException;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class ExceptionPracticeTest {
    public static int quotient(int numerator, int denominator)
        throws ArithmeticException{
        return numerator / denominator;
    }
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        boolean continueloop = true;
        do{
            try{
                System.out.print("Enter integer for numerator: ");
                int numerator = cin.nextInt();
                System.out.print("Enter integer for denominator: ");
                int denominator = cin.nextInt();
                int result = quotient(numerator, denominator);
                System.out.printf("%nResult: %d / %d = %d%n",numerator,denominator,result);
                continueloop = false;
            }
            catch(InputMismatchException inputMismatchException){
                System.err.printf("%nException: %s%n",inputMismatchException);
                cin.nextLine();
                System.out.printf(
                "You must enter integers. Please try again. %n%n");
            }
            catch(ArithmeticException dividebyzeroException){
                System.err.printf("%nException: %s%n",dividebyzeroException);
                System.out.printf(
                "Zero is an invalid denominator. Please try again.%n%n");
            }
            
        }while (continueloop);
    }
}
