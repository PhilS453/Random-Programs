import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class ExceptionABCtest {
    public static void main(String [] args){
        Scanner cin = new Scanner(System.in);
        boolean continueloop = true;
        do{
           try{
               System.out.print("Enter numerator: ");
               int numerator = cin.nextInt();
               System.out.println();
               System.out.print("Enter Denominator");
               int denominator = cin.nextInt();
               int showException = divideByZero(numerator,denominator);
               int showException2 = dividebyEven(numerator,denominator);
               continueloop = false;
            }
           catch(ExceptionA exA){
                System.out.println(exA.getMessage());
            }
           
        }while(continueloop);
    }
    
    
    public static int divideByZero(int i,int j) throws exceptionB{
        if(j == 0){
            throw new exceptionB("Exception B caught by its superclass///Cannot divide Zero");
        }
        return i/j;
    }
    public static int dividebyEven(int i, int j) throws exceptionC{
        if((j%2 !=0)){
            throw new exceptionC("Exception C caught by its superclass/////Denominator must be Even");
        }
        return i/j;
    }
}
