import java.io.*;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class IOexceptions {
    public static void main(String[] args){
        try{
            FileReader FileIn = new FileReader("bogus.txt");
            System.out.println(FileIn.read());
            FileIn.close();
        }
        catch(Exception ExceptionIO){
            System.out.printf("%s%n%s",ExceptionIO,"INPUT ERROR");
        }
       
    }

}
