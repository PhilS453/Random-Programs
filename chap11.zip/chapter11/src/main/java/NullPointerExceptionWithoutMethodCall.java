import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class NullPointerExceptionWithoutMethodCall {
    public static void main(String[] args){
        Scanner cin = new Scanner(System.in);
        String nullString = null;
        try{
            System.out.print(nullString.length());
        }
        catch(NullPointerException NullPointerException){
            System.err.printf("%nException: %s%n%s",NullPointerException,"Null cannot be printed");
            cin.nextLine();
            
        }
    }
    
}
