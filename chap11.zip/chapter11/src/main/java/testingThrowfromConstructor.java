/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class testingThrowfromConstructor {
    public static void main(String[]args){
        try{
            ThrowingFromConstructor obj = new ThrowingFromConstructor(5,-5);
        }
        catch(NegativeException e){
            System.out.print(e.getMessage());
        }

        
    }
}
