import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class temperature {
    public static void main(String[]args){
        String startTemp = 
                JOptionPane.showInputDialog("Enter Farenheeit Temp");
        
        int faren = Integer.parseInt(startTemp);
        float Celsius = (faren - 32) * 5 / 9;
        System.out.print(Celsius);
        JOptionPane.showMessageDialog(null,"Your temp in Celsius is "+Celsius,
                "Temp Conversion",JOptionPane.PLAIN_MESSAGE);
        
    }

}
