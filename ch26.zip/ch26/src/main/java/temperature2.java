import javax.swing.JOptionPane;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class temperature2 {
    public static void main(String[]args){
        String question = 
                JOptionPane.showInputDialog("1:farenheit to celsius\n2:celsius to kelvin");
        int answer = Integer.parseInt(question);
        if(answer == 1){
            String startTemp = 
                JOptionPane.showInputDialog("Enter Farenheeit Temp");
        
            int faren = Integer.parseInt(startTemp);
            int Celsius = (faren -  32)*5/9;
            JOptionPane.showMessageDialog(null,"Your temp in Celsius is "+Celsius,
                "Temp Conversion",JOptionPane.PLAIN_MESSAGE);
        }
        else{
            String startTemp2=
                    JOptionPane.showInputDialog("Enter Celsius Temp");
            int cels = Integer.parseInt(startTemp2);
            double Kelvin = cels + 273.15;
            JOptionPane.showMessageDialog(null,"Your temp in Kelvin is " + Kelvin,
                    "Temp Conversion",JOptionPane.PLAIN_MESSAGE);
        }
    }
}