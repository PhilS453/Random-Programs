import java.security.SecureRandom;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JFrame;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */

public class GuesstheNumber {
    private static final SecureRandom randomNumbers = new SecureRandom();
    public static void main(String[]args) throws InterruptedException{
        int winner = 1+randomNumbers.nextInt(100);
        String firstGuess = 
                JOptionPane.showInputDialog("Guess the number 1-100!");
        
        int guess = Integer.parseInt(firstGuess);
        int continues = 1;
        while(continues == 1){
            guess = Integer.parseInt(firstGuess);
            if(guess == winner){
                String answer = JOptionPane.showInputDialog("Play Again? enter 1 ");
                continues = Integer.parseInt(answer);
                winner = 1 + randomNumbers.nextInt(100);
            }
            else if(guess < winner){
                JOptionPane.showMessageDialog(null,"Your guess is too low",
                        "GUESS TOO LOW!!!",JOptionPane.ERROR_MESSAGE);
                firstGuess = JOptionPane.showInputDialog("Guess again!");
            }
            else{
                JOptionPane.showMessageDialog(null,"Your guess is too high",
                        "GUESS TOO HIGH !!!!",JOptionPane.INFORMATION_MESSAGE);
                firstGuess = JOptionPane.showInputDialog("Guess again!");
            }
        }

    }
}
