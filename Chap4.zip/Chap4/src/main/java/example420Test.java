import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example420Test {
    public static void main(String [] args){
        example420 employee1 = new example420("",0.0,0.0);
        example420 employee2 = new example420("",0.0,0.0);
        example420 employee3 = new example420("",0.0,0.0);
        example420 employee4 = new example420("",0.0,0.0);
        Scanner cin = new Scanner(System.in);
        int counter = 0;
        while(counter<4){
            System.out.print("Enter employee " +(counter+1)+" name:");
            String name = cin.next();
            employee1.setName(name);
            System.out.print("Enter employee " +(counter+1)+" hours:");
            double hours = cin.nextDouble();
            employee1.setHoursWorked(hours);
            System.out.print("Enter employee " +(counter+1)+" hourly pay:");
            double hourlyPay = cin.nextDouble();
            employee1.setHourlyPay(hourlyPay);
            counter++;
            System.out.print("Enter employee " +(counter+1)+" name:");
            name = cin.next();
            employee2.setName(name);
            System.out.print("Enter employee " +(counter+1)+" hours:");
            hours = cin.nextDouble();
            employee2.setHoursWorked(hours);
            System.out.print("Enter employee " +(counter+1)+" hourly pay:");
            hourlyPay = cin.nextDouble();
            employee2.setHourlyPay(hourlyPay);
            counter++;
            System.out.print("Enter employee " +(counter+1)+" name:");
            name = cin.next();
            employee3.setName(name);
            System.out.print("Enter employee " +(counter+1)+" hours:");
            hours = cin.nextDouble();
            employee3.setHoursWorked(hours);
            System.out.print("Enter employee " +(counter+1)+" hourly pay:");
            hourlyPay = cin.nextDouble();
            employee3.setHourlyPay(hourlyPay);
            counter++;
            System.out.print("Enter employee " +(counter+1)+" name:");
            name = cin.next();
            employee4.setName(name);
            System.out.print("Enter employee " +(counter+1)+" hours:");
            hours = cin.nextDouble();
            employee4.setHoursWorked(hours);
            System.out.print("Enter employee " +(counter+1)+" hourly pay:");
            hourlyPay = cin.nextDouble();
            employee4.setHourlyPay(hourlyPay);
            counter++;
        }
        double grosspay = employee1.weeklyPay(employee1.getHoursWorked(),
                employee1.getHourlyPay());
        System.out.printf("Employee1 has a gross pay of: %.2f",grosspay);
        System.out.println();
        grosspay = employee2.weeklyPay(employee2.getHoursWorked(),
                employee2.getHourlyPay());
        System.out.printf("Employee2 has a gross pay of: %.2f",grosspay);
        System.out.println();
        grosspay = employee3.weeklyPay(employee3.getHoursWorked(),
                employee3.getHourlyPay());
        System.out.printf("Employee3 has a gross pay of: %.2f",grosspay);
        System.out.println();
        grosspay = employee4.weeklyPay(employee4.getHoursWorked(),
                employee4.getHourlyPay());
        System.out.printf("Employee4 has a gross pay of: %.2f",grosspay);
    }
}
