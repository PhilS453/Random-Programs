import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example430 {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        int count = 0;
        int count2 = 0;
        System.out.print("Enter the length of the side of a square: ");
        int side = cin.nextInt();
        if(side == 1){
            System.out.print("*");
        }
        else if(side == 2){
            System.out.print("**\n");
            System.out.print("**");
        }
        else if(side == 3){
            System.out.print("***\n");
            System.out.print("* *\n");
            System.out.print("***");
        }
        else if(side == 4){
            System.out.print("****\n");
            while(count < 2){
                System.out.print("*  *\n");
                count++;
            }
            System.out.print("****");
        }
        else if(side == 5){
            while(count < 1){
                System.out.print("*****\n");
                while(count2<(side - 2)){
                    System.out.print("*   *\n");
                    count2++;
                }
                System.out.print("*****");
                count++;
            }
        }
        else if(side == 6){
            while(count < 1){
                System.out.print("******\n");
                while(count2<(side - 2)){
                    System.out.print("*    *\n");
                    count2++;
                }
                System.out.print("******");
                count++;
            }
        }
        else if(side == 7){
            while(count < 1){
                System.out.print("*******\n");
                while(count2<(side - 2)){
                    System.out.print("*     *\n");
                    count2++;
                }
                System.out.print("*******");
                count++;
            }
        }
        else if(side == 8){
            while(count < 1){
                System.out.print("********\n");
                while(count2<(side - 2)){
                    System.out.print("*      *\n");
                    count2++;
                }
                System.out.print("********");
                count++;
            }
        }
        else if(side == 9){
            while(count < 1){
                System.out.print("*********\n");
                while(count2<(side - 2)){
                    System.out.print("*       *\n");
                    count2++;
                }
                System.out.print("*********");
                count++;
            }
        }
        else if(side == 10){
            while(count < 1){
                System.out.print("**********\n");
                while(count2<(side - 2)){
                    System.out.print("*        *\n");
                    count2++;
                }
                System.out.print("**********");
                count++;
            }
        }
        else if(side == 11){
            while(count < 1){
                System.out.print("***********\n");
                while(count2<(side - 2)){
                    System.out.print("*         *\n");
                    count2++;
                }
                System.out.print("***********");
                count++;
            }
        }
        else if(side == 12){
            while(count < 1){
                System.out.print("************\n");
                while(count2<(side - 2)){
                    System.out.print("*          *\n");
                    count2++;
                }
                System.out.print("************");
                count++;
            }
        }
        else if(side == 13){
            while(count < 1){
                System.out.print("*************\n");
                while(count2<(side - 2)){
                    System.out.print("*           *\n");
                    count2++;
                }
                System.out.print("*************");
                count++;
            }
        }
        else if(side == 14){
            while(count < 1){
                System.out.print("**************\n");
                while(count2<(side - 2)){
                    System.out.print("*            *\n");
                    count2++;
                }
                System.out.print("**************");
                count++;
            }
        }
        else if(side == 15){
            while(count < 1){
                System.out.print("***************\n");
                while(count2<(side - 2)){
                    System.out.print("*             *\n");
                    count2++;
                }
                System.out.print("***************");
                count++;
            }
        }
        else if(side == 16){
            while(count < 1){
                System.out.print("****************\n");
                while(count2<(side - 2)){
                    System.out.print("*              *\n");
                    count2++;
                }
                System.out.print("****************");
                count++;
            }
        }
        else if(side == 17){
            while(count < 1){
                System.out.print("*****************\n");
                while(count2<(side - 2)){
                    System.out.print("*               *\n");
                    count2++;
                }
                System.out.print("*****************");
                count++;
            }
        }
        else if(side == 18){
            while(count < 1){
                System.out.print("******************\n");
                while(count2<(side - 2)){
                    System.out.print("*                *\n");
                    count2++;
                }
                System.out.print("******************");
                count++;
            }
        }
        else if(side == 19){
            while(count < 1){
                System.out.print("*******************\n");
                while(count2<(side - 2)){
                    System.out.print("*                 *\n");
                    count2++;
                }
                System.out.print("*******************");
                count++;
            }
        }
        else if(side == 20){
            while(count < 1){
                System.out.print("********************\n");
                while(count2<(side - 2)){
                    System.out.print("*                  *\n");
                    count2++;
                }
                System.out.print("********************");
                count++;
            }
        }
    }
}
