import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example422 {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter a number N : ");
        int n = cin.nextInt();
        int counter = 1;
        System.out.print("N\t10*N\t100*N\t1000*N\n");
        System.out.println();
        while(counter != (n+1)){
            System.out.print(counter+"\t"+(10*counter)+"\t"+(100*counter)+"\t"+(1000*counter));
            System.out.println();
            counter++;
        }
        
    }
}
