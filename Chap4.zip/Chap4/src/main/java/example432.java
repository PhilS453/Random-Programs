import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example432 {
    public static void main(String[]args){
        Scanner input = new Scanner(System.in);
        System.out.print("WARNING PROGRAM ONLY RUNS WITH 5 digit binary!");
        System.out.print("\nEnter 5 digit number in binary");
        int num = input.nextInt();
        int originalEntry = num;
        int num1 = num / 10000;
        num1 = num1 * 16;
        num = num % 10000;
        int num2= num / 1000;
        num2 = num2 * 8;
        num = num % 1000;
        int num3 = num / 100;
        num3 = num3 * 4;
        num = num%100;
        int num4 = num / 10;
        num4 = num4 * 2;
        num = num %10;
        num = num * 1;
        int decimalNum = (num+num1+num2+num3+num4);
        System.out.print("Binary numbered entered: "+originalEntry);
        System.out.print(" is the decimal number: "+decimalNum);
    }
}

