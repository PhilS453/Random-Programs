/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example420 {
    private String name;
    private double hoursWorked;
    private double hourlyPay;
    
    public example420(String name,double hours,double hourlyPay){
        this.name = name;
        this.hoursWorked = hours;
        this.hourlyPay = hourlyPay;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setHoursWorked(double hours){
        this.hoursWorked = hours;
    }
    public double getHoursWorked(){
        return hoursWorked;
    }
    public void setHourlyPay(double pay){
        this.hourlyPay = pay;
    }
    public double getHourlyPay(){
        return hourlyPay;
    }
    public double weeklyPay(double hours,double hourlyPay){
        double pay = 0.0;
        double overtimePay = hourlyPay + (hourlyPay /2);
        if(hours > 40){
            double overtime = (hours - 40);
            pay = (40 * hourlyPay) + (overtimePay * overtime);
        }
        else if(hours <= 40){
            pay = hours * hourlyPay;
        }
        return pay;
    }
}
