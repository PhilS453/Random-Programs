import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example437 {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter 3 sides of a right triangle!");
        System.out.print("\n Enter the largest side: ");
        int sideC = cin.nextInt();
        sideC = sideC * sideC;
        System.out.print("Enter the next smallest side: ");
        int sideB = cin.nextInt();
        sideB = sideB * sideB;
        System.out.print("Enter the third and final side: ");
        int sideA = cin.nextInt();
        sideA = sideA * sideA;
        if((sideC == (sideB + sideA))){
            System.out.print("That is a triangle proven by Pythagorean's Theorum");
            System.out.print(" of right triangles.");
        }
        else{
            System.out.print("That is not a right triangle because it does not");
            System.out.print(" satisfy the conditions of Pythagorean's Theorum.");
        }
    }
}
