import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example438BTest {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("This program will show the value of e: ");
        System.out.print("\n");
        System.out.print("Enter a number: ");
        int N = cin.nextInt();
        double counter = 0.0;
        double factorial = 1.0;
        double total = 0.0;
        while(counter != (N)){
            factorial = factorial +(factorial* counter);
            total+=(1/factorial);
            counter++;
        }
        System.out.print("     "+(total+1));
        double newTotal = total + 1;
        System.out.print(newTotal);
    } 
}
