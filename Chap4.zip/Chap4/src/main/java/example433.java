/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example433 {
    public static void main(String[]args){
        int counter = 0;
        int otherCounter = 0;
        int anotherCounter = 0;
        while(anotherCounter < 4){
            counter=0;
            otherCounter = 0;
            while(counter <8){
                System.out.print("* ");
                System.out.print(" ");
                counter++;
            }
            System.out.println();
            while(otherCounter < 8){
                System.out.print(" ");
                System.out.print("* ");
                otherCounter++;
            }
            System.out.println();
            anotherCounter++;
            
        }
    }
}
