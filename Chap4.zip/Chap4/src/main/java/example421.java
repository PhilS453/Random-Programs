import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example421 {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        int counter = 0;
        int number = 0;
        int largest = 0;
        while(counter < 10){
            System.out.print("Enter a number: ");
            number = cin.nextInt();
            if(number > largest){
                largest = number;
            }
            counter++;
        }
        System.out.print("The largest entered was: "+largest);
    }
}
