/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example418 {
    private int accountNum;
    private int beginningBalance;
    private int charged;
    private int credits;
    private int allowedLimit;
    
    public example418(int number , int startingBalance,int charges,
            int credits,int limit){
        this.accountNum = 0;
        this.beginningBalance = 0;
        this.charged = 0;
        this.credits = 0;
        this.allowedLimit = 0;
        
    }
    
    public void setAccount(int number){
        this.accountNum = number;
    }
    public int getAccount(){
        return accountNum;
    }
    public void setBalance(int balanceNum){
        this.beginningBalance = balanceNum;
    }
    public int getBalance(){
        return beginningBalance;
    }
    public void setCharged(int chargeNum){
        this.charged = chargeNum;
    }
    public double getCharged(){
        return charged;
    }
    public void setCredits(int creditNum){
        this.credits = creditNum;
    }
    public int getCredits(){
        return credits;
    }
    public void setAllowedLimit(int limitNum){
        this.allowedLimit = limitNum;
    }
    public int getAlowedLimit(){
        return allowedLimit;
    }
    public void newBalance(int balanceNum,int chargeNum,int creditNum,
            int limitNum){
        int newBalance = (balanceNum + chargeNum - creditNum);
        if(newBalance > limitNum){
            System.out.print("Credit Limit exceeded! Your card should have been declined!!!!!! ");
        }
        else{
            System.out.print("Your new balance is: "+newBalance);
        }
        
    }
}
