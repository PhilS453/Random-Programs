import java.util.Scanner;
import java.lang.Math;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example440 {
    public static void main(String[]args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the population and the growth rate");
        double population = input.nextDouble();
        double growthRate = input.nextDouble();
        double variable = (1+growthRate);
        double newpop=0.0;
        //double growthAndTime=(double)Math.pow(variable,time);
       // double pop = population*growthAndTime;
        int counter = 1;
        System.out.print("YEAR\tAnticipated Pop\t\tIncrease Since 2023\n");
        while(counter < 76){
            int time =counter;
            double growthAndTime = 0.0;
            double pop = 0.0;
            growthAndTime=(double)Math.pow(variable,time);
            pop = population*growthAndTime;
            newpop += pop;
            if(counter == 1){
                System.out.print(counter+"\t"+pop+"\t"+(pop - population));
                System.out.println();
            }
            else{
            System.out.print(counter+"\t"+pop+"\t"+(pop - population));
            System.out.println();   
            }
            counter++;
        }
    }
}

