
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example423 {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        int counter = 0;
        int number = 0;
        int largest = 0;
        int secondLargest = 0;
        int numHolder=0;
        while(counter < 10){
            System.out.print("Enter a number: ");
            number = cin.nextInt();
            if(number > secondLargest){
                if( number > largest){
                    numHolder = largest;
                    largest = number;
                    secondLargest = numHolder;
                }
                else{
                    secondLargest = number;
                }
            }
                    
       
            counter++;
        }
        System.out.print("The second largest is: "+secondLargest);
        System.out.print("\nThe largest is: "+largest);
    }
}
