import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example419 {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        double sale = 0.0;
        double total = 0.0;
        int cont = 1;
        while(cont != -1){
            System.out.print("Enter sale: ");
            sale = cin.nextDouble();
            total = total + sale;
            System.out.print("Enter -1 to quit//Enter any number to continue");
            cont = cin.nextInt();
        }
        double earnings = (.09 * total)+200;
        System.out.printf("Employees earnings are:%.2f ",earnings);
    }
}
