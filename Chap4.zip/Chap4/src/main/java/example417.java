import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example417 {
    public static void main(String[] args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter how many trips you will log: ");
        int num = cin.nextInt();
        int counter = 0;
        //double totalmiles = 0.0;
        double totalMiles = 0.0;
        double totalGallons = 0.0;
        while(counter < num){
            System.out.print("\nEnter miles driven for trip " +(counter+1)+":");
            int miles = cin.nextInt();
            System.out.print("Enter the gallons used for trip " +(counter+1)+":");
            int gallons = cin.nextInt();
            
            totalMiles += miles;
            totalGallons += gallons;
            System.out.print("Trip "+(counter + 1)+" went "+miles+" miles");
            System.out.print(" and used "+ gallons+" gallons");
            counter++;
        }
        System.out.print("\nTotal miles: "+totalMiles);
        System.out.print("\nTotal gallons: "+totalGallons);
        System.out.print("\nThe total miles per gallon for trips entered is:"+(totalMiles / totalGallons));
    }
}
