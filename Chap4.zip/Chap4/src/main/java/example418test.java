import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example418test {
    public static void main(String [] args){
        Scanner cin = new Scanner(System.in);
        example418 customer1 = new example418(0,0,0,0,0);
        example418 customer2 = new example418(0,0,0,0,0);
        example418 customer3 = new example418(0,0,0,0,0);
        //using while loop since only using 3 customers
        int counter = 0;
        while(counter < 3){
            System.out.print("Enter account number: ");
            int accNum = cin.nextInt();
            customer1.setAccount(accNum);
            System.out.print("Enter starting balance: ");
            int balanceStart = cin.nextInt();
            customer1.setBalance(balanceStart);
            System.out.print("Enter the charges: ");
            int charges = cin.nextInt();
            customer1.setCharged(charges);
            System.out.print("Enter the credits: ");
            int credits = cin.nextInt();
            customer1.setCredits(credits);
            System.out.print("Enter the limit: ");
            int limit = cin.nextInt();
            customer1.setAllowedLimit(limit);
            System.out.println();
            System.out.print("Testing over/under credit limit\n");
            customer1.newBalance(balanceStart, charges, credits, limit);
            System.out.println();
            counter++;
            System.out.print("Enter account number: ");
            accNum = cin.nextInt();
            customer2.setAccount(accNum);
            System.out.print("Enter starting balance: ");
            balanceStart = cin.nextInt();
            customer2.setBalance(balanceStart);
            System.out.print("Enter the charges: ");
            charges = cin.nextInt();
            customer2.setCharged(charges);
            System.out.print("Enter the credits: ");
            credits = cin.nextInt();
            customer2.setCredits(credits);
            System.out.print("Enter the limit: ");
            limit = cin.nextInt();
            customer2.setAllowedLimit(limit);
            System.out.println();
            System.out.print("Testing over/under credit limit\n");
            customer2.newBalance(balanceStart, charges, credits, limit);
            System.out.println();
            counter++;
            System.out.print("Enter account number: ");
            accNum = cin.nextInt();
            customer3.setAccount(accNum);
            System.out.print("Enter starting balance: ");
            balanceStart = cin.nextInt();
            customer3.setBalance(balanceStart);
            System.out.print("Enter the charges: ");
            charges = cin.nextInt();
            customer3.setCharged(charges);
            System.out.print("Enter the credits: ");
            credits = cin.nextInt();
            customer3.setCredits(credits);
            System.out.print("Enter the limit: ");
            limit = cin.nextInt();
            customer3.setAllowedLimit(limit);
            System.out.println();
            System.out.print("Testing over/under credit limit\n");
            customer3.newBalance(balanceStart, charges, credits, limit);
            System.out.println();
            counter++;
            
        }
    }
}
