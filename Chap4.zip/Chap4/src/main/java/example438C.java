
import java.util.Scanner;
import java.lang.Math;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example438C {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("This program will show the value of e raised to the power x: ");
        System.out.print("\n");
        System.out.print("Enter x: ");
        int N = cin.nextInt();
        double counter = 0.0;
        double factorial = 1.0;
        double total = 0.0;
        double multiplier = N;
        double e = 2.7182182845;
        while(counter != (N)){
            if(counter == 0){
                multiplier = N;
            }
            else if(counter == 1){
                multiplier = N*N;
            }
            else if(counter == 2){
                multiplier = N*N*N;
            }
            else if(counter == 256){
                multiplier = N*N*N*N;
            }
            total = total + (multiplier/e);
            counter++;
        }
        System.out.print(total);
    }
}
