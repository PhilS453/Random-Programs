/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example516 {
    int num;
    public example516(int num){
        this.num = num;
    }
    public String asterisk(int num){
        String barchart= "";
        switch (num) {
            case 1:
                barchart = "*";
                break;
            case 2:
                barchart = "**";
                break;
            case 3:
                barchart = "***";
                break;
            case 4:
                barchart = "****";
                break;
            case 5:
                barchart = "*****";
                break;
            case 6:
                barchart = "******";
                break;
            case 7:
                barchart = "*******";
                break;
            case 8:
                barchart = "********";
                break;
            case 9:
                barchart = "*********";
                break;
            case 10:
                barchart = "**********";
                break;
            case 11:
                barchart = "***********";
                break;
            case 12:
                barchart = "************";
                break;
            case 13:
                barchart = "*************";
                break;
            case 14:
                barchart = "**************";
                break;
            case 15:
                barchart = "***************";
                break;
            case 16:
                barchart = "****************";
                break;
            case 17:
                barchart = "*****************";
                break;
            case 18:
                barchart = "******************";
                break;
            case 19:
                barchart = "*******************";
                break;
            case 20:
                barchart = "********************";
                break;
            case 21:
                barchart = "*********************";
                break;
            case 22:
                barchart = "**********************";
                break;
            case 23:
                barchart = "***********************";
                break;
            case 24:
                barchart = "************************";
                break;
            case 25:
                barchart = "*************************";
                break;
            case 26:
                barchart = "**************************";
                break;
            case 27:
                barchart = "****************************";
                break;
            case 28:
                barchart = "*****************************";
                break;
            case 29:
                barchart = "******************************";
                break;
            case 30:
                barchart = "******************************";
                break;
            default:
                break;
        }
        return barchart;
    }
}
