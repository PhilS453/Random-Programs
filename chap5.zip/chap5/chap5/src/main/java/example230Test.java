import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example230Test {
    public static void main(String[]args){
        example230 StateCode = new example230(0," "," ");
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter states code: ");
        String stateCode = cin.next();
        StateCode.setState(stateCode);
    }
}
