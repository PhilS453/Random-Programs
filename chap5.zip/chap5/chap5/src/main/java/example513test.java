/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example513test {
    public static void main(String[] args){
        example513 factorial = new example513(5);
        System.out.print("N\tFactorial");
        System.out.println();
        for(int i = 1;i<=20;i++){
            long var = factorial.factorial(i);
            System.out.print(i+"\t"+var);
            System.out.println();
        }
        System.out.print("\nFactorial 100 may be too large even with long type");
    }
}
