/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example524 {
    public static void main(String [] args){
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        for(int i = 0;i<1;i++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        for(int j = 0;j<3;j++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print(" ");
        System.out.print(" ");

        for(int k = 0;k<5;k++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print(" ");
        for(int a = 0; a<7;a++){
            System.out.print("*");
        }
        System.out.println();
        for(int b = 0; b<9;b++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print(" ");
        for(int g = 0; g<7;g++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print(" ");
        System.out.print(" ");

        for(int k = 0;k<5;k++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        for(int j = 0;j<3;j++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        for(int i = 0;i<1;i++){
            System.out.print("*");
        }
        
        
    }
}

