import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example516test {
    public static void main(String[] args){
        example516 bar = new example516(0);
        Scanner cin = new Scanner(System.in);
        String var1 = "";
        String var2 = "";
        String var3 = "";
        String var4 = "";
        String var5 = "";
        System.out.print("You will enter 5 integers!");
        System.out.println();
        for (int i = 0; i < 5;i++){
            System.out.print("Enter an integer: ");
            int num = cin.nextInt();
            switch (i) {
                case 0:
                    var1 = bar.asterisk(num);
                    break;
                case 1:
                    var2 = bar.asterisk(num);
                    break;
                case 2:
                    var3 = bar.asterisk(num);
                    break;
                case 3:
                    var4 = bar.asterisk(num);
                    break;
                default:
                    var5 = bar.asterisk(num);
                    break;
            }
        }
        System.out.print(var1+"\n");
        System.out.print(var2+"\n");
        System.out.print(var3+"\n");
        System.out.print(var4+"\n");
        System.out.print(var5+"\n");
    }
}
