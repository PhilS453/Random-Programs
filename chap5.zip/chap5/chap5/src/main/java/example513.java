import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example513{
    long num;
    public example513(long num){
        this.num = num;
    }
    public long factorial(int num){
        int counter = (num -1 );
        if(counter == 0){
            long factorial = 1;
            return factorial;
        }
        long factorial = num * counter;
        while(counter != 1){
            counter--;
            factorial = factorial * counter;
        }
        return factorial;
        
    } 
}
