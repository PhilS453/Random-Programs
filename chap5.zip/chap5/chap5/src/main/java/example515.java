/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example515 {
    public static void main(String[]args){
       // String line1 = "*";
       // String line2 = "**";
       // String line3 = "***";
        //String line4 = "****";
        //String line5 = "*****";
       // String line6 = "******";
       // String line7 = "*******";
       // String line8 = "********";
       // String line9 = "*********";
       // String line10 ="**********";
        
        for(int i = 0;i<1;i++){
            System.out.print("*");
        }
        System.out.println();
        for(int j = 0; j<2;j++){
            System.out.print("*");
        }
        System.out.println();
        for(int k=0;k<3;k++){
            System.out.print("*");
        }
        System.out.println();
        for(int z = 0;z<4;z++){
            System.out.print("*");
        }
        System.out.println();
        for(int m=0;m<5;m++){
            System.out.print("*");
        }
        System.out.println();
        for(int n=0;n<6;n++){
            System.out.print("*");
        }
        System.out.println();
        for(int a=0;a<7;a++){
            System.out.print("*");
        }
        System.out.println();
        for(int b=0;b<8;b++){
            System.out.print("*");
        }
        System.out.println();
        for(int c=0;c<9;c++){
            System.out.print("*");
        }
        System.out.println();
        for(int d=0;d<10;d++){
            System.out.print("*");
        }
        System.out.println();
        for(int d=0;d<10;d++){
            System.out.print("*");
        }
        System.out.println();
        for(int c=0;c<9;c++){
            System.out.print("*");
        }
        System.out.println();
        for(int b=0;b<8;b++){
            System.out.print("*");
        }
        System.out.println();
        for(int a=0;a<7;a++){
            System.out.print("*");
        }
        System.out.println();
        for(int n=0;n<6;n++){
            System.out.print("*");
        }
        System.out.println();
        for(int m=0;m<5;m++){
            System.out.print("*");;
        }   
        System.out.println();
        for(int z = 0;z<4;z++){
            System.out.print("*");
        }
        System.out.println();
        for(int k=0;k<3;k++){
            System.out.print("*");
        }
        System.out.println();
        for(int j = 0; j<2;j++){
            System.out.print("*");
        }
        System.out.println();
        for(int i = 0;i<1;i++){
            System.out.print("*");
        }
        System.out.println();
        for(int d=0;d<10;d++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print(" ");
        for(int c=0;c<9;c++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("  ");
        for(int b=0;b<8;b++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("   ");
        for(int b=0;b<7;b++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("    ");
        for(int b=0;b<6;b++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("     ");
        for(int b=0;b<5;b++){
            System.out.print("*");
        }
        System.out.println();  
        System.out.print("      ");
        for(int b=0;b<4;b++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("       ");
        for(int b=0;b<3;b++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("        ");
        for(int b=0;b<2;b++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("         ");
        for(int b=0;b<1;b++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("         ");
        for(int i = 0;i<1;i++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("        ");
        for(int j = 0; j<2;j++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("       ");
        for(int j = 0; j<3;j++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("      ");
        for(int b=0;b<4;b++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("     ");
        for(int b=0;b<5;b++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("    ");
        for(int b=0;b<6;b++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("   ");
        for(int b=0;b<7;b++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print("  ");
        for(int b=0;b<8;b++){
            System.out.print("*");
        }
        System.out.println();
        System.out.print(" ");
        for(int c=0;c<9;c++){
            System.out.print("*");
        }
        System.out.println();
        for(int d=0;d<10;d++){
            System.out.print("*");
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}
    