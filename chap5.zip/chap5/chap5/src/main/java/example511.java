import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example511 {
    public static void main (String [] args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter how many numbers you want to compare: ");
        int amount = cin.nextInt();
        int counter = 0;
        System.out.print("Enter the first integer: ");
        int smallest = cin.nextInt();
        while(counter < amount-1){
            System.out.print("Enter an integer: ");
            int num = cin.nextInt();
            if(num < smallest){
                smallest = num;
            }
            counter++;
        }
        System.out.print("The smallest is "+smallest);
    }
}
