import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example517 {
    public static void main(String[] args){
        Scanner cin = new Scanner(System.in);
        double product1 = 2.98;
        double product2 = 4.50;
        double product3 = 9.98;
        double product4 = 4.49;
        double product5 = 6.87;
        double product1Total = 0.0;
        double product2Total = 0.0;
        double product3Total = 0.0;
        double product4Total = 0.0;
        double product5Total = 0.0;
        double total=0.0;
        System.out.print("Product 1 = 2.98\nProduct 2 = 4.50");
        System.out.print("\nProduct 3 = 9.98\nProduct 4 = 4.49");
        System.out.print("\nProduct 5 = 6.87\n");
        System.out.print("Product numbers: 1,2,3,4,5\n");
        int cont = 1;
        while(cont != -1){
            System.out.print("Enter a product number (-1 to quit): ");
            int productNum = cin.nextInt();
            switch (productNum) {
                case 1:
                    product1Total+=product1;
                    break;
                case 2:
                    product2Total+=product2;
                    break;
                case 3:
                    product3Total+=product3;
                    break;
                case 4:
                    product4Total+=product4;
                    break;
                case 5:
                    product5Total+=product5;
                    break;
                default:
                    System.out.print("INVALID ENTRY!");
                    break;
            }
            if(productNum == -1){
                cont = -1;
            }
        }
        total = product1Total + product2Total + product3Total+product4Total+product5Total;
        System.out.println();
        System.out.printf("Procuct 1 total: %.2f",product1Total);
        System.out.println();
        System.out.printf("Procuct 2 total: %.2f",product2Total);
        System.out.println();
        System.out.printf("Procuct 3 total: %.2f",product3Total);
        System.out.println();
        System.out.printf("Procuct 4 total: %.2f",product4Total);
        System.out.println();
        System.out.printf("Procuct 5 total: %.2f",product5Total);
        System.out.printf("\nTotal: %.2f",total);
    }
    
}
