/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Pieexample2 {
    public static void main(String[] args){
        double num = 4.0;
        double total = 0.0;
        for(int i = 1;i<1300;i+=2){
            if(i==1){
                total+=(num/i);
            }
            else if(i==3){
                total-=(num/i);
            }
            else if(((i-1)%4) == 0){
                total+=(num/i);
            }
            else{
                total-=(num / i);
            }
            System.out.print(i+"\t"+total+"\n");
        }

        System.out.print(total);
        System.out.print("\nafter 1253 3.14 remains the answer");
    }
}