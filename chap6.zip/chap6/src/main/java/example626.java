import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example626 {
    public static void main(String[]args){
        
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter a number to reverse it: ");
        int number = cin.nextInt();
        System.out.print(ReverseNum(number));
    }
    
    
    public static int ReverseNum(int num){
       int num1 = num / 10000;
        num = num % 10000;
        int num2= num / 1000;
        num = num % 1000;
        int num3 = num / 100;
        num = num%100;
        int num4 = num / 10;
        num = num %10;
        int newnum =(num*10000)+(num4*1000)+(num3*100)+(num2*10)+num1;
        return newnum;
        
        
    }
}
