import java.util.Scanner;
import java.security.SecureRandom; 
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example631 {
    private static final SecureRandom mysterNum = new SecureRandom();
    private static int totalGuess = 0;
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Guess the number! 1 - 100\n");
        int winner = 1 + mysterNum.nextInt(100);
        while(true){
            System.out.print("Guess a num 1 - 100: \n");
            int userGuess = cin.nextInt();
            addGuesses();
            if(userGuess == winner){
                System.out.print("YOU GUESS CORRECTLY\n");
                if(totalGuess <=10){
                    System.out.print("AHA! YOU KNOW THE SECRET!!");
                }
                else{
                        System.out.print("You can do better!");
                    }
                System.out.print("PLAY AGAIN?: 1 = yes// 0 == no");
                int playAgain = cin.nextInt();
                if(playAgain == 0){
                    break;
                }
                else{
                    winner = 1 + mysterNum.nextInt(100);
                }
            }
            else{
                guess(userGuess,winner);
            }
            
        }
    }
    
    
    public static void guess(int num,int correctNum){
        if(num>correctNum){
            System.out.print("Your Guess is too high!!!\n");
        }
        else{
            System.out.print("Your Guess is too Low!!!\n");
        }
    }
    
    public static void addGuesses(){
        totalGuess+=1;
    }
}
