import java.security.SecureRandom;
import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example629 {
    private static final SecureRandom coinFlip = new SecureRandom();
    private enum coinFlip{Heads,Tails};
    private static final int Heads = 1;
    private static final int Tails = 2;
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        int heads = 0;
        int tails = 0;
        while(true){
            System.out.print("Menu:\n");
            System.out.print("1) Toss coin: \n");
            System.out.print("2)Quit: ");
            int answer = cin.nextInt();
            if(answer == 2){
                break;
            }
            int toss = flip();
            switch(toss){
                case Heads:
                    System.out.print("It was Heads!\n");
                    heads+=1;
                    break;
                case Tails:
                    System.out.print("It was tails!\n");
                    tails+=1;
                    break;
            }
            //if(toss == 1){
                
            //    System.out.print("HEADS!\n");
            //    heads+=1;
            //}
           // if(toss == 2){
           //     System.out.print("TAILS!\n");
            //    tails+=1;
                
            //}
            //System.out.print("1) play again or -1) quit");
            //answer = cin.nextInt();
           // if(answer == -1){
           //     break;
           // }
        }
        System.out.print("Heads: "+heads);
        System.out.print("\nTails: "+tails);
    }
    
    public static int flip(){
        int headsOrTails = 1+coinFlip.nextInt(3);
        if(headsOrTails == 1){
            return 1;
        }
        else{
            return 2;
        }
    }
}
