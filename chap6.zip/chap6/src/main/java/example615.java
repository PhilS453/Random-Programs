import java.util.Scanner;
import java.lang.Math;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example615 {
    public static void main(String []args){
        Scanner cin = new Scanner(System.in);
        for(int i=0;i<2;i++){
            System.out.print("Enter side1: ");
            double side1 = cin.nextDouble();
            System.out.print("Enter side2: ");
            double side2 = cin.nextDouble();
            System.out.print("The hypotenuse is: ");
            System.out.printf("%.2f",hypotenuse(side1,side2));
            System.out.print("\n");
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    public static double hypotenuse(double a,double b){
        double side1 = Math.pow(a,2);
        double side2 = Math.pow(b,2);
        double hypotenuse = Math.sqrt(side1+side2);
        return hypotenuse;
    }
}
