import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example21 {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter integer a: ");
        int integerA = cin.nextInt();
        System.out.print("Enter integer b: ");
        int integerB = cin.nextInt();
        System.out.printf("integer division yields: %d\n",intDivision(integerA,integerB));
        System.out.printf("remainder division yields: %d",modulusDivision(integerA,integerB));
        System.out.print("\nEnter a digit 1-99999 to see it in a different light: ");
        int integerC = cin.nextInt();
        displayDigits(integerC);
        
        
        
    }
    
    public static int intDivision(int a, int b){
        return (a / b);
    }
    public static int modulusDivision(int a, int b){
        return(a%b);
    }
    
    public static void displayDigits(int c){
        int num = c;
        if(num>=10000){
           int num1 = num / 10000;
            num = num % 10000;
            int num2= num / 1000;
            num = num % 1000;
            int num3 = num / 100;
            num = num%100;
            int num4 = num / 10;
            num = num %10;
            System.out.print(num1+ "    ");
            System.out.print(num2+ "    ");
            System.out.print(num3+ "    ");
            System.out.print(num4+ "    ");
            System.out.print(num); 
        }
        else if(num >= 1000){
             int num2= num / 1000;
            num = num % 1000;
            int num3 = num / 100;
            num = num%100;
            int num4 = num / 10;
            num = num %10;
            System.out.print(num2+ "    ");
            System.out.print(num3+ "    ");
            System.out.print(num4+ "    ");
            System.out.print(num);
        }
        else if(num >= 100){
            int num3 = num / 100;
            num = num%100;
            int num4 = num / 10;
            num = num %10;
            System.out.print(num3+ "    ");
            System.out.print(num4+ "    ");
            System.out.print(num);
        }
        else if(num>=10){
            int num4 = num / 10;
            num = num %10;
            System.out.print(num4+ "    ");
            System.out.print(num);
        }
        else if(num>=0){
            System.out.print(num);
        }
    }
    
    
}
