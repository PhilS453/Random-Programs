import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example614 {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("This method will find x raised to the power y! \n");
        int answer = 1;
        while(answer != -1){
            System.out.print("Enter x: ");
            int x = cin.nextInt();
            System.out.print("Enter y: ");
            int y = cin.nextInt();
            System.out.printf("X rasied to the power Y: ");
            System.out.print(integerPower(x,y));
            System.out.println();
            System.out.print("enter -1 to quit or any number to continue: ");
            answer = cin.nextInt();
        }
    }      

    
    
    
    public static int integerPower(int x, int y){
        int total =1;
        for(int i = 0;i<y;i++){
            total = total * x;
        }
        return total;
    }
    
}

