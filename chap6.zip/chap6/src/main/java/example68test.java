import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example68test {
    public static void main(String[] args){
        example68 customer1 = new example68(0.0);
        example68 customer2 = new example68(0.0);
        example68 customer3 = new example68(0.0);
        example68 customer4 = new example68(0.0);
        Scanner cin = new Scanner(System.in);
        System.out.print("How many hours was customer1 parked: ");
        double hours = cin.nextDouble();
        customer1.setHours(hours);
        customer1.setCharges(customer1.calculateCharges(customer1.getHours()));
        System.out.print("Customer 1 parked for: ");
        System.out.print(customer1.getHours());
        System.out.println();
        System.out.print("Customer 1 charges are as follows: $");
        System.out.printf("%.2f",customer1.getCharges());
        System.out.println();
        System.out.print("How many hours was customer2 parked: ");
        hours = cin.nextDouble();
        customer2.setHours(hours);
        customer2.setCharges(customer2.calculateCharges(customer2.getHours()));
        System.out.println();
        System.out.print("Customer 2 parked for: ");
        System.out.print(customer2.getHours());
        System.out.println();
        System.out.print("Customer 2 charges are as follows: $");
        System.out.printf("%.2f",customer2.getCharges());
        System.out.println();
        System.out.print("How many hours was customer3 parked: ");
        hours = cin.nextDouble();
        customer3.setHours(hours);
        customer3.setCharges(customer3.calculateCharges(customer3.getHours()));
        System.out.print("Customer 3 parked for: ");
        System.out.print(customer3.getHours());
        System.out.println();
        System.out.print("Customer 3 charges are as follows: $");
        System.out.printf("%.2f",customer3.getCharges());
        System.out.println();
        System.out.print("How many hours was customer4 parked: ");
        hours = cin.nextDouble();
        customer4.setHours(hours);
        customer4.setCharges(customer4.calculateCharges(customer4.getHours()));
        System.out.print("Customer 4 parked for: ");
        System.out.print(customer4.getHours());
        System.out.println();
        System.out.print("Customer 4 charges are as follows: $");
        System.out.printf("%.2f",customer4.getCharges());
        double total = customer1.getCharges() + customer2.getCharges()+customer3.getCharges()+customer4.getCharges();
        System.out.println();
        System.out.printf("Total for yesterday = $%.2f",total);
    }
}
