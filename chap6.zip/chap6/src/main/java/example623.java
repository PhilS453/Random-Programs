import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example623 {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("ENTER 3 doubles to find the minimum: ");
        double dub1 = cin.nextDouble();
        double dub2 = cin.nextDouble();
        double dub3 = cin.nextDouble();
        System.out.printf("The smallest is: %.3f",Minimum3(dub1,dub2,dub3));
    }
    
    
    
    
    
    
    
    
    public static double Minimum3(double x, double y, double z){
        double minimum = Math.min(x,(Math.min(y, z)));
        return minimum;
    }
}
