import java.util.Scanner;
import java.security.SecureRandom;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example635 {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Computer-Assisted Instruction!\n");
        System.out.print("Answer -1 to stop\n");
        while(true){
            int num1 = multiQuestion();
            int num2 = multiQuestion();
            int correctResult = answer(num1,num2);
            question(num1,num2);
            System.out.print("Enter your answer: ");
            int answer = cin.nextInt();
            while(answer != correctResult){
                wrongAnswer();
                answer = cin.nextInt();
            }
            message();
            continueMessage();
            int response = cin.nextInt();
            if(Continue(response)){
                break;
            }
            
        }
        
        
        
        
    }
    //random num generator method
    public static int multiQuestion(){
        SecureRandom intNum = new SecureRandom();
        int num1 = intNum.nextInt(10);
        return num1;
    }
    //prompt question method
    public static void question(int num1,int num2){
        System.out.print("What is "+num1+" times "+num2+"?\n");
    }
    //correct answer method
    public static int answer(int num1 , int num2){
        return (num1*num2);
    }
    public static void message(){
        System.out.print("Very Good!!\n");
    }
    public static void wrongAnswer(){
        System.out.print("No. Please Try again: ");
    }
    public static void continueMessage(){
        System.out.print("Continue? -1 to quit\n");
    }
    public static boolean Continue(int response){
        return (response == -1);
    }
}
