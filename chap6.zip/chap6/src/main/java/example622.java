import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example622 {
    public static void main(String[]args){
       Scanner cin = new Scanner(System.in); 
       while(true){
           System.out.print("Is your temperature in Celsius(1) or Farenheit(2)\n");
           int answer = cin.nextInt();
           if(answer == 1){
               System.out.print("Enter the temperature in Celsius: ");
               int temp = cin.nextInt();
               System.out.printf("Farenheit : %.2f",Farenheit(temp)); 
           }
           if(answer == 2){
                System.out.print("Enter the temperature in Farenheit: ");
                int temp = cin.nextInt();
                System.out.printf("Celsius : %.2f",Celsius(temp)); 
           }
           System.out.print("\nEnter 0 to quit:");
           answer = cin.nextInt();
           if(answer == 0){
               break;
           }
       } 
        
        
    }
    
    
    public static double Celsius(int temp){
        double celsius = 5.0 / 9.0 *(temp-32);
        return celsius;
    }
    
    public static double Farenheit(int temp){
        double farenheit = 9.0 / 5.0 * temp +32;
        return farenheit;
    }
}
