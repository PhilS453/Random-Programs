import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example616 {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Is multiple?\n");
        for(int i =0;i<5;i++){
            System.out.print("Enter first num: ");
            int num1 = cin.nextInt();
            System.out.print("Enter second num: ");
            int num2 = cin.nextInt();
            if(isMultiple(num1,num2)){
                System.out.print("ITS A MULTIPLE!!!!");
            }
            else{
                System.out.print("NOT A MULTIPLE");
            }
        }
    }
    
    
    
    public static boolean isMultiple(int x, int y){
        if(x == 0){
            return false;
        }
        return (y%x)==0;
    }
}
