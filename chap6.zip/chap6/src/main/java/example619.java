import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example619 {
    public static void main(String[] args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Input the side of a square: ");
        int side = cin.nextInt();
        System.out.print("Input the fill of the square: ");
        char fill = cin.next().charAt(0);
        squareOfAsterisks(side,fill);
      
    }
    
    
    public static void squareOfAsterisks(int side,char fill){
        for(int i =0;i<side;i++){
            for(int j = 0; j<side;j++){
                System.out.print(fill);
            }
            System.out.println();
        }
    }
    
    
}