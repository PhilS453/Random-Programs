/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example68 {
    private double hours;
    private double charge;
    
    public example68(double hours){
        this.hours = hours;
    }
    
    public void setHours(double hours){
        this.hours = hours;
    }
    public void setCharges(double charges){
        this.charge = charges;
    }
    public double getCharges(){
        return charge;
    }
    public double getHours(){
        return hours;
    }
    
    public double calculateCharges(double time){
        double charges = 0.0;
        if(time<=3){
            charges = 2.00;
            return charges;
        }
        if(time>=18){
            charges = 10;
            return charges;
        }
        double minCharge = 2.00;
        double extraTime = (time-3);
        charges = minCharge + (extraTime*.50);
        return charges;
    }
}
