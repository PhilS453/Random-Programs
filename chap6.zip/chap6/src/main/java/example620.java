import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example620 {
    public static void main(String [] args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter the radius of your cirlce: ");
        double radius = cin.nextDouble();
        System.out.printf("%.2f",circleArea(radius));
        
        
        
        
        
    }
    
    public static double circleArea(double radius){
        double PI = 3.14159;
        double rad = Math.pow(radius,2);
        return(PI*rad);
    }
}
