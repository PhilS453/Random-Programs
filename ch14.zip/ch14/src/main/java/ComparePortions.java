
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class ComparePortions {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter your first 5 letter word: ");
        String firstWord = cin.nextLine();
        System.out.print("Enter your second 5 letter word: \n");
        String secondWord = cin.nextLine();
        System.out.print("Where would you like to start your comparission?: ");
        int startSpot = cin.nextInt();
        System.out.print("How many characters of the two 5 letter strings shall we compare?: ");
        int compareNum = cin.nextInt();
        if(firstWord.regionMatches(true,startSpot,secondWord,startSpot,compareNum)){
            System.out.print("The portions are equal!!!!");
        }
        else{
            System.out.print("The portions are not equal!!!!");
        }
    }

}
