import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class ReverseReverse {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter a sentence ");
        String number = cin.nextLine();
        
        String[] tokens = number.split(" ");
        System.out.printf("Number of elements: %d%n the tokens are:%n",
                tokens.length);
        for(int i = tokens.length-1;i>0;i--){
            System.out.print(tokens[i]+" ");
        }
        
        
        
        
        
    }
}