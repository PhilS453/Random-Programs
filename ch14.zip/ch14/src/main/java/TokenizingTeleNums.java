import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class TokenizingTeleNums {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter a telephone number ");
        String number = cin.nextLine();
        
        String[] tokens = number.split("\\W");
        System.out.printf("Number of elements: %d%n the tokens are:%n",
                tokens.length);
//        for(String token : tokens){
//            System.out.print(token);
//        }
        for(int i=0;i<tokens.length;i++){
            if(i==2){
                System.out.print(" ");
            }
            System.out.print(tokens[i]);
            
        }
        
        
        
        
        
    }
}
