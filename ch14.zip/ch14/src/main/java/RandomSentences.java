import java.security.SecureRandom;
        
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class RandomSentences {
    public static void main(String[]args){
        SecureRandom randomNumbers = new SecureRandom();
        String[] articleCap = {"The","A","One","Some","Any"};
        String[] article = {"the","a","one","some","any"};
        String[] nouns = {"boy","girl","dog","town","car"};
        String[] verbs = {"drove","jumped","ran","walked","skipped"};
        String[] prepositions = {"to","from","over","under","on"};
        int pick = randomNumbers.nextInt(5);
        String first = articleCap[pick];
        int pick2 = randomNumbers.nextInt(5);
        String second = first.concat(" "+nouns[pick2]);
        int pick3 = randomNumbers.nextInt(5);
        String third = second.concat(" "+verbs[pick3]);
        int pick4 = randomNumbers.nextInt(5);
        String fourth = third.concat(" "+prepositions[pick4]);
        int pick5 = randomNumbers.nextInt(5);
        String fifth = fourth.concat(" "+article[pick5]);
        int pick6 = randomNumbers.nextInt(5);
        String last = fifth.concat(" "+nouns[pick6]+".");
        System.out.print(last);

        
    }
}

