import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Tokenizing {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter a phrase: ");
        String number = cin.nextLine();
        String[] tokens = number.split(" ");
        System.out.printf("Number of elements: %d%nthe tokens that start with b are:%n",
                tokens.length);
        for(int i = 0;i<tokens.length;i++){
            if(tokens[i].startsWith("b")){
                System.out.print(tokens[i]+" ");
            }
        }
        
        
    }
}
