import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class compareSTR {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter your first word: ");
        String firstWord = cin.nextLine();
        System.out.print("Enter your second word: ");
        String secondWord = cin.nextLine();
        if(firstWord.compareTo(secondWord)==0){
            System.out.print("The strings are equal!!!");
        }
        if(firstWord.compareTo(secondWord)==-1){
            System.out.print("The first string is less than the second!");
        }
        if(firstWord.compareTo(secondWord)==1){
            System.out.print("The first string is greater than the second!!");
        }
        if(firstWord.compareTo(secondWord)==32){
            System.out.print("The first string is greater than the second!!");
        }
        if(firstWord.compareTo(secondWord)==-32){
            System.out.print("The first string is less than the second!!");
        }
        
    }

    
    
    
    
}
