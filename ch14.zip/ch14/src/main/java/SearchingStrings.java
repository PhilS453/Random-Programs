import java.util.Arrays;
import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class SearchingStrings {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String sentence = cin.nextLine();
        char[] letter = {'a','b','c','d','e','f','g','h','i','j','k',
        'l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
        char[] capLetter={'A','B','C','D','E','F','G','H','I','J','K',
            'L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
        int letterCount[];
        letterCount = new int[26];
        int count = 0;
        
        for(int j = 0; j<letter.length;j++){
            count = 0;
            for(int k = 0;k<sentence.length();k++){
                if((sentence.charAt(k)==letter[j]||sentence.charAt(k)==capLetter[j])){
                    count++;
                }
            }
            letterCount[j] = count;
        }
        System.out.print("Letter\t\tTotal\n");
        for(int i = 0;i<letter.length;i++){
            System.out.printf("%s or %s\t\t%d%n",letter[i],capLetter[i],letterCount[i]);
                    
        }
        
        

        
        
    }
}
