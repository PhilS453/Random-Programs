//reads in 5 integers and displays the smallest and largest of the group
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example224 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter first integer: ");
        int n1 = input.nextInt();
        System.out.print("Enter second integer: ");
        int n2 = input.nextInt();
        System.out.print("Enter third integer: ");
        int n3 = input.nextInt();
        System.out.print("Enter fourth integer: ");
        int n4 = input.nextInt();
        System.out.print("Enter the fifth integer: ");
        int n5 = input.nextInt();
        if(n1>n2){
            if(n1>n3){
                if(n1>n4){
                    if(n1>n5){
                        System.out.print(n1);
                        System.out.print(" is the largest ");
                    }
                }
            }
        }
        if(n1<n2){
            if(n1<n3){
                if(n1<n4){
                    if(n1<n5){
                        System.out.print(n1);
                        System.out.print(" is the smallest ");
                    }
                }
            }
        }
        if(n2>n1){
            if(n2>n3){
                if(n2>n4){
                    if(n2>n5){
                        System.out.print(n2);
                        System.out.print(" is the largest ");
                    }
                }
            }
        }
        if(n2<n1){
            if(n2<n3){
                if(n2<n4){
                    if(n2<n5){
                        System.out.print(n2);
                        System.out.print(" is the smallest ");
                    }
                }
            }
        }
        if(n3>n1){
            if(n3>n2){
                if(n3>n4){
                    if(n3>n5){
                        System.out.print(n3);
                        System.out.print(" is the largest ");
                    }
                }
            }
        }
        if(n3<n1){
            if(n3<n2){
                if(n3<n4){
                    if(n3<n5){
                        System.out.print(n3);
                        System.out.print(" is the smallest ");
                    }
                }
            }
        }
        if(n4>n1){
            if(n4>n2){
                if(n4>n3){
                    if(n4>n5){
                        System.out.print(n4);
                        System.out.print(" is the largest ");
                    }
                }
            }
        }
        if(n4<n1){
            if(n4<n2){
                if(n4<n3){
                    if(n4<n5){
                        System.out.print(n4);
                        System.out.print(" is the smallest ");
                    }
                }
            }
        }
        if(n5>n1){
            if(n5>n2){
                if(n5>n3){
                    if(n5>n4){
                        System.out.print(n5);
                        System.out.print(" is the largest ");
                    }
                }
            }
        }
        if(n5<n1){
            if(n5<n2){
                if(n5<n3){
                    if(n5<n4){
                        System.out.print(n5);
                        System.out.print(" is the smallest ");
                    }
                }
            }
        }
    }
}
