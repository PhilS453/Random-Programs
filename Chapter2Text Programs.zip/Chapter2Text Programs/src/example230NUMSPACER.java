import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author phils
 */
public class example230NUMSPACER {
    public static void main(String[]args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter 5 digit number");
        int num = input.nextInt();
        int num1 = num / 10000;
        num = num % 10000;
        int num2= num / 1000;
        num = num % 1000;
        int num3 = num / 100;
        num = num%100;
        int num4 = num / 10;
        num = num %10;
        System.out.print(num1+ "    ");
        System.out.print(num2+ "    ");
        System.out.print(num3+ "    ");
        System.out.print(num4+ "    ");
        System.out.print(num);
    }
}
