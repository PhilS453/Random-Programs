/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example231MATHTABLE {
    public static void main(String[]args){
        System.out.print("number\tsquare\tcube\n");
        System.out.print(0+"\t");
        System.out.print(0+"\t");
        System.out.print(0+"\n");
        System.out.print(1+"\t");
        System.out.print(1+"\t");
        System.out.print(1+"\n");
        System.out.print(2+"\t");
        System.out.print(4+"\t");
        System.out.print(8+"\n");
        System.out.print(3+"\t");
        System.out.print(9+"\t");
        System.out.print(27+"\n");
        System.out.print(4+"\t");
        System.out.print(16+"\t");
        System.out.print(64+"\n");
        System.out.print(5+"\t");
        System.out.print(25+"\t");
        System.out.print(125+"\n");
        System.out.print(6+"\t");
        System.out.print(36+"\t");
        System.out.print(216+"\n");
        System.out.print(7+"\t");
        System.out.print(49+"\t");
        System.out.print(343+"\n");
        System.out.print(8+"\t");
        System.out.print(64+"\t");
        System.out.print(512+"\n");
        System.out.print(9+"\t");
        System.out.print(81+"\t");
        System.out.print(729+"\n");
        System.out.print(10+"\t");
        System.out.print(100+"\t");
        System.out.print(1000+"\n");
        
    }
}
