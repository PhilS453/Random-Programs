/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
//import java.util.lang.math;
/**
 *
 * @author phils
 */
public class example234WorldPopulationGrowth {
    public static void main(String[]args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the population and the growth rate");
        double population = input.nextDouble();
        double growthRate = input.nextDouble();
        System.out.print("Enter the amount of years");
        int time = input.nextInt();
        double variable = (1+growthRate);
        double growthAndTime=(double)Math.pow(variable,time);
        double pop = population*growthAndTime;
        System.out.print("After "+time+" years, the population will increase");
        System.out.print(" to " + pop);
    }
}