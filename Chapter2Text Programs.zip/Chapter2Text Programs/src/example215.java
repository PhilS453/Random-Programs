//takes in 2 integers and displays +,-,/,* of the 2 nums
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */

import java.util.Scanner;

public class example215{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the first integer: ");
        int num1 = input.nextInt();
        System.out.print("Enter the second integer");
        int num2 = input.nextInt();
        int sum = num1+num2;
        int difference = num1 - num2;
        double quotient = num1 / num2;
        int multiplied = num1 * num2;
        System.out.print("The sum is: ");
        System.out.print(sum);
        System.out.print("\nThe 1st number minus the 2nd number is: ");
        System.out.print(difference);
        System.out.print("\nThe 1st number divides the 2nd number by: ");
        System.out.print(quotient);
        System.out.print("\nThe numbers multiplied by another is: ");
        System.out.print(multiplied);

    }//end method main
}
