/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
/**
 *
 * @author phils
 */
public class example228 {
    public static void main(String[] args){
        Scanner input=new Scanner(System.in);
        double pi = 3.14159;
        System.out.print("Enter the radius");
        int radius = input.nextInt();
        System.out.print("The diameter is: ");
        System.out.print(2*radius);
        System.out.print("\nThe circumference is: ");
        System.out.print(2*pi*radius);
        System.out.print("\nThe area is: ");
        System.out.print(pi*radius*radius);
    }
   
}
