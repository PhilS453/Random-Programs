//reads in 3 numbers displays largest,smallest,average,sum,product

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */


import java.util.Scanner;
//this program takes in 3 integers  and returns the largest of the 3 and smallest and returns math operations
public class example217{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter first integer");
        int num1 = input.nextInt();
        System.out.print("Enter second integer");
        int num2 = input.nextInt();
        System.out.print("Enter third integer");
        int num3 = input.nextInt();
        if(num1>num2){
            if(num1>num3){
                System.out.print(num1);
                System.out.print(" is largest\n");
            }
        }
        if(num1<num2){
            if(num1<num3){
                System.out.print(num1);
                System.out.print(" is smallest \n");
            }
        }
        if(num2<num1){
            if(num2<num3){
                System.out.print(num2);
                System.out.print(" is smallest\n");
            }
        }
        if(num2>num1){
            if(num2>num3){
                System.out.print(num2);
                System.out.print(" is largest\n");
            }
        }
        if(num3<num1){
            if(num3<num2){
              System.out.print(num3);
              System.out.print(" is smallest\n");
            }
        }
        if(num3>num1){
          if(num3>num2){
              System.out.print(num3);
              System.out.print(" is largest\n");
              
          }
        }
        int sum = num1 + num2 + num3;
        System.out.print("\nThe sum is: ");
        System.out.print(sum);
        int average = (num1 + num2 + num3) / 3;
        System.out.print("\nThe average is: ");
        System.out.print(average);
        int product = (num1 * num2 * num3);
        System.out.print("\nThe product is: ");
        System.out.print(product);



    }
}
