/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
/**
 *
 * @author phils
 */
public class example232ODDEVENINTS {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter 5 positive or negative integers: ");
        int num1 =  input.nextInt();
        int num2 = input.nextInt();
        int num3 = input.nextInt();
        int num4 = input.nextInt();
        int num5 = input.nextInt();
        int posCount = 0;
        int negCount = 0;
        int zeroCount=0;
        if(num1 > 0){
            posCount = posCount + 1;
        }
        if(num2 > 0){
            posCount = posCount + 1;
        }
        if(num3 > 0){
            posCount = posCount + 1;
        }
        if(num4 > 0){
           posCount = posCount + 1;
        }
        if(num5 > 0){
            posCount = posCount + 1;
        }
        if(num1 < 0){
            negCount = negCount + 1;
        }
        if(num2 < 0){
            negCount = negCount + 1;
        }
        if(num3 < 0){
            negCount = negCount + 1;
        }
        if(num4 < 0){
            negCount = negCount + 1;
        }
        if(num5 < 0){
            negCount = negCount + 1;
        }
        if(num1 == 0){
            zeroCount = zeroCount + 1;
        }
        if(num2 == 0){
            zeroCount = zeroCount + 1;
        }
        if(num3 == 0){
            zeroCount = zeroCount + 1;
        }
        if(num4 == 0){
            zeroCount = zeroCount + 1;
        }
        if(num5 == 0){
            zeroCount = zeroCount + 1;
        }
        System.out.print("Number of positive numbers is: "+posCount+"\n");
        System.out.print("Number of negative numbers is: "+negCount+"\n");
        System.out.print("Number of Zeros is: "+zeroCount);
        
    }
}
