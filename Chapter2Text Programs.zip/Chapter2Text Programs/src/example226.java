
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example226 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter first integer and second integer");
        int num1 = input.nextInt();
        int num2 = input.nextInt();
        if((num1 % num2)==0){
            System.out.print("The first number is a multiple of the second!");
        }
        if((num1%num2)!=0){
            System.out.print("The first number is not a multiple of the second!");
        }
     }
}
