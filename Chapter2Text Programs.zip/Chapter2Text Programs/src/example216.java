//reads in 2 integers... displays largest or smallest or equivalecy of the 2
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */

import java.util.Scanner;

public class example216{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter first integer");
        int num1 = input.nextInt();
        System.out.print("Enter second integer");
        int num2 = input.nextInt();
        if(num1>num2){
            System.out.printf("%d>%d%n",num1,num2);
        }
        if (num1 < num2){
            System.out.printf("%d<%d%n",num1,num2);
        }
        if (num1 == num2){
            System.out.printf("%d=%d%n",num1,num2);
        }
    }
}

