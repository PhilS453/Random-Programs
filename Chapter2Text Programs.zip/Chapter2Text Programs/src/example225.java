
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class example225 {
     public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter first integer");
        int num1 = input.nextInt();
        if((num1 % 2)==0){
            System.out.print("The number is even!");
            
        }
        if((num1%2)!=0){
            System.out.print("The number is odd!");
        }
     }
}
