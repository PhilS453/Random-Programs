/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class InheritanceTest {
    public static void main(String[] args){
//        CommishEmployee employee = new CommishEmployee("John","Jacob",
//                "123-45-678",500,.5);
//        System.out.print("Commish Employee info before adding base pay: \n");
//        System.out.print(employee.toString());
//        BaseCommishEmployee employee2 = new BaseCommishEmployee("Mary","Ann",
//        "456-78-901",500,.05,1000);
//        System.out.println();
//        System.out.print("Base salary employee who now recieves a salary: \n");
//        System.out.print(employee2.toString());
          HourlyEmployee employee3 = new HourlyEmployee("Johnny","Johnson"
          ,"455-56-667",40,20);
          System.out.print("Using GetMethods \n");
          System.out.printf("%s %s","First Name: ",employee3.getFirst());
          System.out.printf("%n%s %s","Last Name: ",employee3.getLast());
          System.out.printf("%n%s %s","Social Security Number: ",employee3.getSocial());
          System.out.printf("%n%s %.2f","Hours Worked: ",employee3.getHours());
          System.out.printf("%n%s %.2f","Hourly Wage: ",employee3.getWage());
          System.out.printf("%n%s %.2f%n","Gross Pay: ",employee3.earnings());
          System.out.print("Using toString() method\n");
          System.out.print(employee3.toString());
          
       
        
        
        
        
        
        
        
        
        
    }
}
