/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class HourlyEmployee extends Employee{
    private double hours;
    private double wage;
    
    public HourlyEmployee(String first, String last, String social,
            double hours, double wage){
        super(first,last,social);
        
        if(wage <=0){
            throw new IllegalArgumentException("Wage must be >= 0");
        }
        if(hours <=0 || hours >168){
            throw new IllegalArgumentException("Hours must be from 0 - 168");
        }
        this.hours = hours;
        this.wage = wage;
    }
    
    
    public void setHours(double hours){
        if(hours<=0||hours >168){
            throw new IllegalArgumentException("Hours must be from 0 - 168");
        }
        this.hours = hours;
    }
    
    public void setWage(double wage){
        if(wage <=0){
            throw new IllegalArgumentException("Wage cannot be negative");
        }
        this.wage = wage;
    }
    
    public double getHours(){return hours;};
    
    public double getWage(){return wage;};
    
    public double earnings(){return wage * hours;};
    
    @Override
    public String toString(){
        return String.format("%s %n%s%.2f %n%s%.2f %n%s%.2f",super.toString(),
                "Employee Hours: ", getHours(),"Employee Wage: ",
                getWage(),"Employee Earnings: ",earnings());
    }
}
