/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Rectangle extends Quadrilateral {
    public Rectangle(int topSide, int bottomSide,int leftSide, int rightSide){
        super(topSide,bottomSide,leftSide,rightSide);
    }
    
    public double getArea(int bottomside,int leftside){
        return bottomside * leftside;
    }
}
