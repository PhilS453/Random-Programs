/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Quadrilateral {
    protected int topSide;
    protected int bottomSide;
    protected int leftSide;
    protected int rightSide;
    
    public Quadrilateral(int topSide,int bottomSide,int leftSide,int rightSide){
        if((topSide <=0)||(bottomSide<=0)||(leftSide<=0)||(rightSide<=0)){
            throw new IllegalArgumentException("All sides must be > 0");
        }
    this.topSide = topSide;
    this.bottomSide = bottomSide;
    this.leftSide = leftSide;
    this.rightSide = rightSide;
    
    }
    public void setTopSide(int topLength){
        this.topSide = topLength;
    }
    
    public int getTopLength(){return topSide;};
    
    public void setBottomSide(int bottomLength){
        this.bottomSide = bottomLength;
    }
    
    public int getBottomLength(){return bottomSide;};
    
    
    public void setLeftSide(int leftLength){
        this.leftSide = leftLength;
    }
    
    
    public int getLeftLength(){return leftSide;};
    
    public void setRightSide(int rightLength){
        this.rightSide = rightLength;
    }
    
    public int getRightLength(){return rightSide;};
    
    
    
}
