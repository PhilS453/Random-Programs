/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class commissionEmployee {
    protected final String firstName;
    protected final String lastName;
    protected final String social;
    protected double grossSales;
    protected double commissionRate;
    
    public commissionEmployee(String firstName, String lastName, String social,
            double grossSales,double commissionRate){
        if(grossSales < 0.0){
            throw new IllegalArgumentException("Gross sale must be >= 0.0");
        }
        
        if(commissionRate <=0.0 || commissionRate >= 1.0){
            throw new IllegalArgumentException(
            "Commission rate must be > 0.0 and < 1.0");
        }
        
        this.firstName = firstName;
        this.lastName = lastName;
        this.social = social;
        this.grossSales = grossSales;
        this.commissionRate = commissionRate;
    }
    
    public String getFirstName(){return firstName;};
    
    public String getLastName(){return lastName;};
    
    public String getSocial(){return social;};
    public double getGrossSales() {
        return grossSales;
    }
  
    public void setGrossSales(double grossSales) {
        if(grossSales < 0.0){
            throw new IllegalArgumentException("Gross sales must be >= 0.0");
        }
        this.grossSales = grossSales;
    }

    public double getCommissionRate() {
        return commissionRate;
    }

    public void setCommissionRate(double commissionRate) {
        if(commissionRate <= 0.0|| commissionRate >=1.0){
            throw new IllegalArgumentException(
            "Commission rate must be > 0.0 and < 1.0");
        }
        this.commissionRate = commissionRate;
    }
    
    public double earnings(){
        return getCommissionRate() * getGrossSales();
    }
    @Override
    public String toString(){
        return String.format("%s: %s %s%n%s: %s%n%s: %.2f%n%s: %.2f",
                "commission employee", getFirstName(),getLastName(),
                "social security number",getSocial(),
                "gross sales",getGrossSales(),
                "commission rate",getCommissionRate());
    }
    
    
}
