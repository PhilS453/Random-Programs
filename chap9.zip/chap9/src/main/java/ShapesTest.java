/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class ShapesTest {
    public static void main(String [] args){
        Rectangle rect = new Rectangle(5,5,5,5);
        Square square = new Square(5,6,7,8);
        Parrellogram parr = new Parrellogram(5,6,7,8,10);
        Trapezoid trap = new Trapezoid(3,4,5,6,7);
        int Length = rect.getBottomLength();
        int Height = rect.getLeftLength();
        System.out.printf("%s %.2f","Rectangle Area is ",
                rect.getArea(Length, Height));
        Length = square.getBottomLength();
        System.out.printf("%n%s %.2f","Square Area is ",square.getArea(Length));
        Height = parr.getHeight();
        int base = parr.getBottomLength();
        System.out.printf("%n%s %.2f","Parrelelogram Area is ",
                parr.CalcArea(base,Height));
        Length = trap.getTopLength();
        base = trap.getBottomLength();
        Height = trap.getHeight();
        System.out.printf("%n%s %.2f","Trapezoid area is ",
                trap.CalcArea(Length, base, Height));
        
        
      
        
        
        
        
        
        
        
        
        
    }
}
