/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class CommishEmployee extends Employee{
    private double grossSales;
    private double commishRate;
    
    public CommishEmployee(String first,String last,String social,
            double grossSales,double commishRate){
        super(first,last,social);
    if(grossSales < 0.0){
        throw new IllegalArgumentException("Gross sale must be >= 0.0");
        }
        
    if(commishRate <=0.0 || commishRate >= 1.0){
        throw new IllegalArgumentException(
        "Commission rate must be > 0.0 and < 1.0");
        }    
    this.commishRate = commishRate;
    this.grossSales = grossSales;
        
        
    }

    public double getGrossSales() {
        return grossSales;
    }

    public void setGrossSales(double grossSales) {
        this.grossSales = grossSales;
    }

    public double getCommishRate() {
        return commishRate;
    }

    public void setCommishRate(double commishRate) {
        this.commishRate = commishRate;
    }

    @Override
    public String toString() {
        return String.format("%s %s:%n %s %.2f %n%s %.2f","Employee Info",
                super.toString(),"Gross Sales is ",getGrossSales(),
                "Commish Rate is ",getCommishRate());
    }
    
    
    
}
