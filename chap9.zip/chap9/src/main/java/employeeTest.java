/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class employeeTest {
    public static void main(String[]args){
        commissionEmployee employee = new commissionEmployee("Bob","Lewis","123-45-678"
        ,5000,.04);
        Basepluscommission basecommissionEmployee = new Basepluscommission(employee.getFirstName(),employee.getLastName()
        ,employee.getSocial(),employee.getGrossSales(),employee.getCommissionRate(),300);
        System.out.printf("Employee information obtained by get methods:%n");
        System.out.printf("%s %s%n","first name is",employee.getFirstName());
        System.out.printf("%s %s%n","last name is",employee.getLastName());
        System.out.printf("%s %s%n","Social Security # is",employee.getSocial());
        System.out.printf("%s %.2f%n","Gross Sales is ",employee.getGrossSales());
        System.out.printf("%s %.2f%n","Commission rate is",employee.getCommissionRate());
        System.out.printf("%s %.2f%n","Base salary is ",basecommissionEmployee.getBaseSalary());
        
        basecommissionEmployee.setBaseSalary(1000);
        
        System.out.printf("%n%s:%n%n%s%n%s%.2f",
                "Updated employee information obatained by toString",
                employee.toString(),"Base Salary: ",basecommissionEmployee.getBaseSalary());
        
        
        
    }
}
