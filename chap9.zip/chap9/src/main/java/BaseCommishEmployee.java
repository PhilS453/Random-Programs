/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class BaseCommishEmployee extends CommishEmployee{
    private double baseSalary;
    
    public BaseCommishEmployee(String first,String last,String social,double grossSales,
            double CommishRate,double baseSalary){
        super(first,last,social,grossSales,CommishRate);
        
         if (baseSalary < 0.0){
            throw new IllegalArgumentException("Base salary  must be >= 0.0");
        }
        this.baseSalary = baseSalary;
    }

    public double getBaseSalary() {
        return baseSalary;
    }

    public void setBaseSalary(double baseSalary) {
        this.baseSalary = baseSalary;
    }
    
    public String toString(){
        return String.format("%s %n %s %.2f",super.toString(),
                "Base Salary is ",getBaseSalary());
    }
    
    
    
}
