
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Employee {
    private String name;
    private String lastName;
    private double monthSalary;
    
    public Employee(String name, String lastName, double monthSalary){
        this.name = "";
        this.lastName = "";
        if(monthSalary > 0){
            this.monthSalary = monthSalary;
        }
    }
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return name;
    }
    
    public void setLastName(String last){
        this.lastName = last;
    }
    
    public String getLastName(){
        return lastName;
    }
    
    public void setMonthSalary(double salary){
        this.monthSalary = salary;
    }
    
    public double getMonthSalary(){
        return monthSalary;
    }
    public double yearlySalary(double salary){
        return (salary * 12);
    }
    public double giveRaise(double Salary){
        double newSalary = Salary * 12;
        return (((newSalary*.10)+newSalary));
    }
}
