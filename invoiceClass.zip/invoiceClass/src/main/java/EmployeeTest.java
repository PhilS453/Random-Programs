import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class EmployeeTest {
    public static void main(String[]args){
        Scanner input = new Scanner(System.in);
        Employee employee1 = new Employee("","",0.0);
        Employee employee2 = new Employee("","",0.0);
        System.out.print("Enter the employees first name: ");
        String name = input.nextLine();
        employee1.setName(name);
        System.out.print("Enter the employees last name: ");
        name = input.nextLine();
        employee1.setLastName(name);
        System.out.print("What is the employees monthly salary?: ");
        double salary = input.nextDouble();
        employee1.setMonthSalary(salary);
        System.out.print("Enter employee2 first name: ");
        String name2 = input.next();
        employee2.setName(name2);
        System.out.print("Enter the employees last name: ");
        name2 = input.next();
        employee2.setLastName(name2);
        System.out.print("What is the employees monthly salary?: ");
        double salary2 = input.nextDouble();
        employee2.setMonthSalary(salary2);
        System.out.print("Employee 1 has a yearly salary of :"+employee1.yearlySalary(salary));
        System.out.print("\nEmployee 2 has a yearly salary of :"+employee2.yearlySalary(salary2));
        double raise1 = employee1.giveRaise(salary);
        double raise2 = employee2.giveRaise(salary2);
        System.out.print("\nEmployee1 has a new yearly salary of : ");
        System.out.printf("%.2f",raise1);
        System.out.print("\n Employee2 has a new yearly salary of: ");
        System.out.printf("%.2f",raise2);
    }
}
