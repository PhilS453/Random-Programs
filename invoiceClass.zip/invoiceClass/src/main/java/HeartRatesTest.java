import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class HeartRatesTest {
    public static void main(String[] args){
        Scanner cin = new Scanner(System.in);
        HeartRates Test1 = new HeartRates("","",0);
        System.out.print("Enter birth year: ");
        int birthYear = cin.nextInt();
        Test1.setYear(birthYear);
        System.out.print("Enter First name: ");
        String fName = cin.next();
        Test1.setName(fName);
        System.out.print("Enter Last name: ");
        String LName = cin.next();
        Test1.setLastName(LName);
        int age = Test1.showYears(birthYear);
        int maxHeartRate = Test1.maxHeart(age);
        double lowTarget = Test1.lowtargetHeart(maxHeartRate);
        double highTarget = Test1.hightargetHeart(maxHeartRate);
        System.out.print("A person of age: "+age);
        System.out.print(" will have a max heart rate of "+maxHeartRate);
        System.out.print(" will have a min and max target ranging from ");
        System.out.print(lowTarget + "-"+highTarget);
        
        
        
        
        
        
        
        
        
        
    }
}
