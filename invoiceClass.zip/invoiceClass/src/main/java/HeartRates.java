/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class HeartRates {
    private String firstName;
    private String lastName;
    private int month;
    private int day;
    private int year;
    
    public HeartRates(String fname,String lname, int num1){
        this.firstName = fname;
        this.lastName = lname;
        this.year = num1;
    }
    
    public void setName(String name){
        this.firstName = name;
    }
    public String getName(){
        return firstName;
    }
    
    public void setLastName(String last){
        this.lastName = last;
    }
    
    public String getLastName(){
        return lastName;
    }
    public void setYear(int yearNum){
        this.year = yearNum;
    }
    public int getYear(){
        return year;
    }
    public int showYears(int YearOfBirth){
        int age = (2023 - YearOfBirth);
        return age;
    }
    public int maxHeart(int age){
        int maxHeartRate = (220 - age);
        return maxHeartRate;
    }
    public double lowtargetHeart(int maxHeartRate){
        double lowTargetHeartRate = (maxHeartRate * .5);
        return lowTargetHeartRate;
    }
    public double hightargetHeart(int maxHeartRate){
        double highTargetHeartRate = (maxHeartRate * .85);
        return highTargetHeartRate;
    }
}
