import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class DateTest {
    public static void main(String[] args){
        Date date1 = new Date(0,0,0);
        System.out.print("You will enter and see the date entered!\n");
        Scanner cin = new Scanner(System.in);
        System.out.print("Enter the month: ");
        int monthNum = cin.nextInt();
        date1.setMonth(monthNum);
        System.out.print("Enter the day: ");
        int dayNum = cin.nextInt();
        date1.setDay(dayNum);
        System.out.print("Enter the year however you prefer: ");
        int yearNum = cin.nextInt();
        date1.setYear(yearNum);
        int monthDisp = date1.getMonth();
        int dayDisp = date1.getDay();
        int yearDisp = date1.getYear();
        System.out.print("Here is the date: ");
        System.out.print(monthDisp+"/"+dayDisp+"/"+yearDisp);
    }
}
