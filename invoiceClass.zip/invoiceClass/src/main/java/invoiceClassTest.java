


import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class invoiceClassTest {
    public static void main(String[] args){
        InvoiceClass invoice1 = new InvoiceClass("","",0,0.0);
        System.out.print("Displaying the constructor: ");
        System.out.print(invoice1.getPart());
        System.out.print("\n");
        System.out.print(invoice1.getDescription());
        System.out.print("\n");
        System.out.print(invoice1.getPurchased());
        System.out.print("\n");
        System.out.print(invoice1.getPrice());
        System.out.print("\nWhat is the part number?: ");
        Scanner input = new Scanner(System.in);
        String part = input.nextLine();
        invoice1.setPart(part);
        System.out.print("Describe the part: ");
        String description = input.nextLine();
        invoice1.setDescription(description);
        System.out.print("How many?: ");        
        int numOfParts=input.nextInt();
        invoice1.setPurchased(numOfParts);
        System.out.print("What is the price of the part?: ");
        double price = input.nextDouble();
        invoice1.setPrice(price);
        double total = invoice1.invoiceTotal(numOfParts,price);
        System.out.print("Here is your total: ");
        System.out.printf("%.2f",total);
        System.out.print("\n");
        System.out.print("invoice1 part number: "+ invoice1.getPart());
        System.out.print("\ninvoice1 part description: "+ invoice1.getDescription());
        System.out.print("\ninvoice1 amount of parts: "+ invoice1.getPurchased());
        System.out.print("\ninvoice1 price of parts: "+ invoice1.getPrice());
    }
}
