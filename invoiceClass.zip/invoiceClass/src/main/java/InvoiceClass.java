

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class InvoiceClass {
    private String partNum;
    private String description;
    private int numPurchased;
    private double price;
    
    public InvoiceClass(String partNum,String description,int numPurchased
    ,double price){
        //setting base values that constuctor will use
        //they can be altered through set methods
        this.partNum = "";
        this.description = "";
        this.numPurchased = 0;
        this.price = 0.0;
    }
    //sets a new part num.. that will differ from constructor
    public void setPart(String part){
        this.partNum = part;
    }
    public String getPart(){
        return partNum;
    }
    public void setDescription(String describe){
        this.description = describe;
    }
    public String getDescription(){
        return description;
    }
    public void setPurchased(int num){
        this.numPurchased = num;
    }
    public int getPurchased(){
        return numPurchased;
    }
    public void setPrice(double pricePer){
        if(pricePer > 0){
            this.price = pricePer;
        }
        else{
            this.price = 0.0;
        }
    }
    public double getPrice(){
        return price;
    }
    public double invoiceTotal(int num, double pricePer){
        return (num * pricePer);
    }
}


//NEED GETINVOICE AMOUNT METHOD..PAGE 102
