/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Date {
    private int month;
    private int day;
    private int year;
    
    
    public Date(int month,int day,int year){
        this.month = month;
        this.day = day;
        this.year = year;
    }
    
    public void setMonth(int monthNum){
        this.month = monthNum;
    }
    public void setDay(int dayNum){
        this.day = dayNum;
    }
    public void setYear(int yearNum){
        this.year = yearNum;
    }
    public int getMonth(){
        return month;
    }
    public int getDay(){
        return day;
    }
    public int getYear(){
        return year;
    }
}
    
