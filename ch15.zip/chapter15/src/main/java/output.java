import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.SecurityException;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Formatter;
import java.util.FormatFlagsConversionMismatchException;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class output {
    public static void main(String[]args){
        try(Scanner input = new Scanner(Paths.get("numbers.txt"))){
            int close=0;
            while(close==0){
                String num = input.nextLine();
                
                try(Formatter output = new Formatter("output.txt")){
                    output.format("%s%n%n",num);
                    output.format("\n");
                    if(num.isBlank()){
                        close=1;
                    }
                }
                catch(IOException | NoSuchElementException | IllegalStateException f){
                    System.err.print("BAD INPUT");

                }
                
                
                
                    
            }
        }
        catch(IOException | NoSuchElementException| IllegalStateException e){
        }
//        try(Formatter output = new Formatter("output.txt")){
//            
//        }
//        catch(SecurityException | FileNotFoundException | FormatterClosedException e){
//            e.printStackTrace();
//        }
        
        
        
        
        
        
        
        
        
        
        
    }
}
