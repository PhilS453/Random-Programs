import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.lang.SecurityException;
import java.util.Arrays;
import java.util.Formatter;
import java.util.FormatFlagsConversionMismatchException;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;
public class TeleNumber {
    public static void main(String[]args){
        try(Formatter output = new Formatter("homework.txt")){
            Scanner input = new Scanner(System.in);
            System.out.printf("%s","enter number");
            int close = 0;
            while(close==0){
                try{
                    Scanner cin = new Scanner(System.in);
                    String phone = cin.next();
                    String letters[][] = {
                        {"n","o","t"},
                        {"u","s","e","d"},
                        {"a","b","c"},
                        {"d","e","f"},
                        {"g","h","i"},
                        {"j","k","l"},
                        {"m","n","o"},
                        {"p","q","r","s"},
                        {"t","u","v"},
                        {"w","x","y","z"}};
                    String[] wordMade = new String[8];
                    char Array[] = phone.toCharArray();
                    int numbers[] = new int[Array.length];
                    for(int i =0; i<numbers.length;i++){
                        numbers[i] = Integer.parseInt(String.valueOf(Array[i]));
                    }
                        for(int first = 0;first < 3;first++){
                            wordMade[0] = letters[numbers[0]][first];
                            for(int second = 0;second<3;second++){
                                wordMade[1]= letters[numbers[1]][second];
                                for (int third = 0;third<3;third++){
                                    wordMade[2] = letters[numbers[2]][third];
                                    for(int fourth = 0; fourth < 3; fourth++){
                                        wordMade[3] = letters[numbers[3]][fourth];
                                        for(int fifth = 0; fifth<3;fifth++){
                                            wordMade[4] = letters[numbers[4]][fifth];
                                            for(int sixth =0; sixth<3; sixth++){
                                                wordMade[5] = letters[numbers[5]][sixth];
                                                for(int seventh=0;seventh<3;seventh++){
                                                    wordMade[6]=letters[numbers[6]][seventh];
                                                    for(int i=0;i<wordMade.length-1;i++){
                                                        output.format(wordMade[i]);
                                                    }
                                                    output.format("\n");
                                    
                                                }
                                
                                            }
                                        }
                                    }
                                }
                            }
                        }
                close = 1;
                    }
                    catch(NoSuchElementException elementException){
                        System.err.println("bad input");
                        input.nextLine();
                    }
                
                System.out.print("?");
                }
            }
        catch(SecurityException | FileNotFoundException | FormatterClosedException e){
            e.printStackTrace();
        }
    }
}
