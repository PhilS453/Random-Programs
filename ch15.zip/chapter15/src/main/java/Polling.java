import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.lang.SecurityException;
import java.util.Arrays;
import java.util.Formatter;
import java.util.FormatFlagsConversionMismatchException;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Polling {
    public static void main(String[]args){
        try(Formatter output = new Formatter("numbers.txt")){
            Scanner cin = new Scanner(System.in);
            System.out.print("Enter poll answers");
            int close = 0;
            while(close ==0){
                try{
                    String pollNum="";
                    pollNum=cin.nextLine();
                    if(pollNum.isBlank()){
                        close =1;
                    }
                    output.format(pollNum);
                }
                catch(NoSuchElementException elementExceptioni){
                    System.err.println("Error with input");
                    cin.nextLine();
                }
            }
            
        }
        catch(SecurityException | FileNotFoundException| FormatterClosedException e){
            e.printStackTrace();
        }
        
        
        
        
        
        
        
        
        
        
        
        
    }
}
