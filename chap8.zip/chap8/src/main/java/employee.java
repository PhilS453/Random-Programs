/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class employee {
    private final String firstname;
    private final String lastname;
    private final Date birthdate;
    private final Date hiredate;
    
    
    public employee(String firstname, String lastname, Date birthdate, Date hiredate){
        this.firstname = firstname;
        this.lastname = lastname;
        this.birthdate = birthdate;
        this.hiredate = hiredate;
    }
    
    public String toString(){
        return String.format("%s, %s Hired: %s Birthday: %s",
                lastname,firstname,hiredate,birthdate);
    }
}
