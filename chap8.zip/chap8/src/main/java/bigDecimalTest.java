import java.util.Scanner;
import java.math.BigDecimal;
import java.text.NumberFormat;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class bigDecimalTest {
    public static void main(String[] args){
        bigDecimal account1 = new bigDecimal("Jane Green",50.00);
        //validation should set account2 to 0.00
        bigDecimal account2= new bigDecimal("John Blue",-7.53);
        //display inititial balance of each object
        System.out.printf("%s balance: $%.2f%n",account1.getName(),
                account1.getBalance());
        System.out.printf("%s balance: $%.2f%n%n",account2.getName(),
                account2.getBalance());
        
        Scanner input =new Scanner(System.in);
        
        System.out.print("Enter the deposit amount for account1: ");
        double depositAmount = input.nextDouble();
        BigDecimal deposit1 = BigDecimal.valueOf(depositAmount);
        System.out.printf("%nadding %.2f to account1 balance %n%n",
                deposit1);
        account1.deposit(depositAmount);
        
        //displaying balances
        System.out.printf("%s balance: $%.2f%n", account1.getName(),
                account1.getBalance());
        System.out.printf("%s balance: $%.2f%n%n",account2.getName(),
                account2.getBalance());
        
        System.out.print("Enter deposit amount for account2: ");
        depositAmount = input.nextDouble();
        System.out.printf("%nadding %.2f to account2 balance%n%n",
                depositAmount);
        account2.deposit(depositAmount); // adding to account 2 balance
        
        //display balances.... same algorithm as before
        System.out.printf("%s balance: $%.2f%n",account1.getName(),
                account1.getBalance());
        System.out.printf("%s balance: $%.2f%n%n",account2.getName(),
                account2.getBalance());
        
        System.out.print("Enter withdraw amount for account2: ");
        double withdrawAmount = input.nextDouble();
        BigDecimal withdraw = BigDecimal.valueOf(withdrawAmount);
        System.out.printf("%nwithdrawing %.2f from account2 balance%n%n",
                depositAmount);
        account2.withdraw(withdrawAmount); // withdrawing from account 2 balance
        
                //display balances.... same algorithm as before
        System.out.printf("%s balance: $%.2f%n",account1.getName(),
                account1.getBalance());
        System.out.printf("%s balance: $%.2f%n%n",account2.getName(),
                account2.getBalance());
    }
}

