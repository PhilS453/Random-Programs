/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class employeeTest {
    public static void main(String[]args){
        Date birth = new Date(7,24,1949);
        Date hire = new Date(3,12,1988);
        employee Employee = new employee("Bob","Blue",birth,hire);
        System.out.print(Employee);
        
    }
}
