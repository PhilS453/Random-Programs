/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Date {
    private int month;
    private int day;
    private int year;
    private String name;
    
    
    
    public Date(int month,int day, int year){
        
        this.month = month;
        this.day = day;
        this.year = year;
        System.out.printf("%d/%d/%d",this);
        
    }
    public Date(String month,int day,int year){
        this.name = month;
        this.day = day;
        this.year= year;
    }
    
    public Date(int day , int year){
        this.day = day;
        this.year = year;
        
        
    }
    
    public void printDate(int month,int day,int year){
        System.out.printf("First method: %d/%d/%d",month,day,year);
    }
}
