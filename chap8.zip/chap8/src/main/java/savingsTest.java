/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class savingsTest {
    public static void main(String[]args){
        savings saver1 = new savings(2000);
        for(int i = 0; i<12;i++){
            System.out.print("\nMonth "+(i+1)+": ");
            System.out.printf("%.2f",saver1.getSavings());
            System.out.println();
            saver1.calcMonthlyInterest(saver1.getSavings(),saver1.getInterest());
            System.out.printf("Month Interest "+ (i+1) +": "+"%.2f",saver1.getSavings());
        }
        savings saver2 = new savings(3000);
        System.out.print("\nACCOUNT 2:");
        saver2.modifyInterest(.05);
        System.out.print(saver2.getSavings());
        System.out.println();
        for(int i = 0;i<12;i++){
            System.out.printf("Month "+(i+1)+" Balance:"+"%.2f",saver2.getSavings());
            System.out.println();
            saver2.calcMonthlyInterest(saver2.getSavings(),saver2.getInterest());
            System.out.printf("Month " +(i+1)+" Interest:"+"%.2f",saver2.getSavings());
            System.out.println();
        }
    }
}
