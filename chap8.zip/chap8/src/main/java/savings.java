/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class savings {
    public static double annualInterestRate = .04;
    private double savingsBalance;
    
    public savings(double amount){
        this.savingsBalance = amount;
    }
    
    public void modifyInterest(double interest){
        this.annualInterestRate = interest;
    }
    public double getInterest(){
        return annualInterestRate;
    }
    public double getSavings(){
        return savingsBalance;
    }
    
    public void calcMonthlyInterest(double savings,double interest){
        this.savingsBalance = savingsBalance + (savings)*(interest/12);
    }
}
