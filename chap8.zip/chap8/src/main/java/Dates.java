/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class Dates {
    private int month;
    private int day;
    private int year;
    private String monthName;
    
    public Dates(int month,int day,int year){
        this.month = month;
        this.day = day;
        this.year = year;
        
    }
    
    public Dates(String month,int day,int year){
        this.monthName = month;
        this.day = day;
        this.year = year;
        
    }
    
    public Dates(int day,int year){
        this.day = day;
        this.year = year;
    }
    
    public void printDateMMDDYY(){
        System.out.printf("%d/%d/%d",month,day,year);
    }
    
    public void printDateMDDYYYY(){
        System.out.printf("%s,%d %d",monthName,day,year);
    }
    public void printDateDDDYYYY(){
        System.out.printf("%d %d",day,year);
    }
}
