import java.util.ArrayList;
import java.util.Arrays;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class integersTest {
    public static void main(String[] args){
        int [] list = {1,5,-3,6,7};
        int [] list1 = {1,5,3,6,3};
        System.out.print("2 arrays will be compared : \n");
        System.out.print(Arrays.toString(list));
        System.out.println();
        System.out.print(Arrays.toString(list1));
        System.out.println();
        setofintegers set1 = new setofintegers(list);
        int [] intersectList = set1.intersection(list, list1);
        boolean boolList1 [] = set1.boolList5(intersectList);
        System.out.print("Intersection as Integers : \n");
        for(int i = 0; i<5;i++){
            System.out.print(intersectList[i]);
            System.out.println();
        }
        int [] unionList = set1.union(list, list1);
        System.out.print("Union List: \n");
        for(int i = 0 ; i < 10 ; i++){
            System.out.print(unionList[i]);
            System.out.println();
        }
        boolean boolList [] = set1.boolList10(unionList);
        System.out.print("Intersection as Booleans : \n");
        System.out.print(Arrays.toString(boolList1));
        System.out.print("\nUnion as Booleans\n");
        System.out.print(Arrays.toString(boolList));
        System.out.print("\nRemoving 5 from the list: ");
        System.out.print("\nLIST AFTER REMOVED: ");
        boolean removedList [] =set1.boolList5(set1.remove(5, list));
        System.out.print(Arrays.toString(removedList));
        System.out.print("\nAdding integer 10 to the list in place of a false entry\n");
        boolean addList [] = set1.boolList5(set1.add(10,list));
        System.out.print(Arrays.toString(addList));
       

        
    }
        
        
}

    
//     ArrayList<Integer> listInts = new ArrayList<Integer>(5);
//        for(int i =0 ; i<5;i++){
//            listInts.add(i,list[i]);
//        }
//        System.out.print("\nAdding 10 to the end: ");
//        listInts.add(10);
//        System.out.print(listInts.toString());
//        System.out.print("\nRemoving 5 from the middle : \n");
//        int location = listInts.indexOf(5);
//        listInts.remove(location);
//        System.out.print(listInts.toString());
//    
    






//     ArrayList<Boolean> list = new ArrayList<Boolean>();
//        setList(list);
//        printList(list);
//    
//    public static void setList(ArrayList list){
//        for(int i = 0;i<10;i++){
//            list.add(i,Boolean.FALSE);
//        }
//    }
//    
//    
//    public static void printList(ArrayList list){
//        for(int i = 0;list.size() >= i;i++){
//            System.out.print(list.get(i));
//            System.out.println();
//        }
//    }

