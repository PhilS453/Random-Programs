import java.util.ArrayList;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class setofintegers {
    private boolean [] list = {false,false,false,false,false};
    private int ints [];
    public setofintegers(int listofInts[]){
        this.ints = listofInts;
        
    }
    
    public int[] intersection(int number[] , int number1[]){
        int intersect [] = {-1,-1,-1,-1,-1};
        for(int i =0; i<5;i++){
            for(int j =0;j<5;j++){
                if(number[i] == number1[j]){
                    intersect[i] = number[i];
                }
                else{
                    continue;
                }
            }
        }
        return intersect;
    }
    
    public int [] union(int number[],int number1[]){
        int union [] = new int [10];
        for(int i = 0;i<5;i++){
            union[i] = number[i];
        }
        for(int j=0; j<5;j++){
            union[j+5] = number[j];
        }
        return union;
    }
    public void setBoolList(){
        for(int i =0;i<5;i++){
            if(ints[i] >= 0 && ints[i] <=100){
                list[i] = true;
            }
        }
    }
    //call for size 10 list since list.length() is not working
    public boolean [] boolList10(int num[]){
        boolean boolList [] = new boolean [10];
        for(int i =0;i<10;i++){
            if(num[i] >= 0 && num[i] <=100){
                boolList[i] = true;
            }
        }
        return boolList;
    }
    //for 5 elements since list.length() is not working
    public boolean [] boolList5(int number[]){
        boolean boolList [] = new boolean [5];
        for(int i =0;i<5;i++){
            if(number[i] >= 0 && number[i] <=100){
                boolList[i] = true;
            }
        }
        return boolList;
    }
    public int [] remove (int number,int ListtoRemoveFrom []){
        int listRemove [] = new int [5];
        System.arraycopy(ListtoRemoveFrom, 0, listRemove, 0, 5);
        for(int i = 0; i<5; i++){
            if(listRemove[i] == number){
                listRemove[i] = -1;
            }
            else{
                continue;
            }
        }
        return listRemove;
    }
    public int [] add (int number,int ListtoAddToo []){
        int listAdd [] = new int [5];
        System.arraycopy(ListtoAddToo, 0, listAdd, 0, 5);
        for(int i = 0; i<5; i++){
            if(listAdd[i] == -1){
                listAdd[i] = number;
                break;
            }
            else{
                continue;
            }
        }
        return listAdd;
    }
        
}
