import java.util.Scanner;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class rectangleTEST {
    public static void main(String[]args){
        Scanner cin = new Scanner(System.in);
        rectangle84 rect1 = new rectangle84();
        System.out.print("Default constructor: ");
        System.out.print("\nLength: "+rect1.getLength());
        System.out.print("\nWidth: "+rect1.getWidth());
        System.out.print("\nPerimeter: "+rect1.calcPerimeter(rect1.getLength(),rect1.getWidth()));
        System.out.print("\nArea: "+rect1.calcArea(rect1.getLength(),rect1.getWidth()));
        System.out.print("\nEnter the length of your rectangle: ");
        float length = cin.nextFloat();
        System.out.print("Enter the width of your rectangle: ");
        float width = cin.nextFloat();
        rect1.setLength(length);
        rect1.setWidth(width);
        System.out.print("\nNew values: ");
        System.out.print("\nLength: "+rect1.getLength());
        System.out.print("\nWidth: "+rect1.getWidth());
        System.out.print("\nPerimeter: "+rect1.calcPerimeter(rect1.getLength(),rect1.getWidth()));
        System.out.print("\nArea: "+rect1.calcArea(rect1.getLength(),rect1.getWidth()));
        
    }
}
