/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class dateclass {
    public static void main(String[]args){
        Dates date1 = new Dates(1,25,1992);
        date1.printDateMMDDYY();
        Dates date2 = new Dates("June",13,1942);
        System.out.println();
        date2.printDateMDDYYYY();
        Dates date3 = new Dates(345,1776);
        System.out.println();
        date3.printDateDDDYYYY();
    }
}
