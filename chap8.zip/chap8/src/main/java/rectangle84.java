/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class rectangle84 {
    private float length=(float) 1.0;
    private float width=(float) 1.0;
    
    public rectangle84(float L,float W){
        if((L<0)||(L>20)){
            throw new IllegalArgumentException("Length must be between 0 and 20");
        }
        else{
            this.length = L;
        }
        if((W<0)||(W>20)){
            throw new IllegalArgumentException("Width must be between 0 and 20");
        }
        else{
            this.width = W;
        }
        
    }
    public rectangle84(){
        this.length = length;
        this.width = width;
    }
    
    public void setLength(float L){
        if((L<0)||(L>20)){
            throw new IllegalArgumentException("Length must be between 0 and 20");
        }
        this.length = L;
    }
    public void setWidth(float W){
        if((W<0)||(W>20)){
            throw new IllegalArgumentException("Length must be between 0 and 20");
        }
        this.width = W;
    }
    public float getLength(){
        return length;
    }
    public float getWidth(){
        return width;
    }
    public float calcPerimeter(float L,float W){
        return ((2*L)+(2*W));
    }
    public float calcArea(float L,float W){
        return (L*W);
    }
    
    
    
    
}
