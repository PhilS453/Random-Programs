import java.math.BigDecimal;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public class bigDecimal {
    private String name; //instance var
    private double balance; //instance var
    
    //constructor that will set values when called
    public bigDecimal(String name, Double balance){
        this.name = name; //set name to name
        
        //balance must be > 0 so validation must be present
        
        if(balance > 0.0){
            this.balance = balance;
        }
    }//end constructor
    
    //deposit method that can be called
    public void deposit(double depositAmount){
        if(depositAmount > 0.0){//validation method;
        balance+=depositAmount;//add to balance
        }
    }
    //this method will read the private var balance that is inside account
    public double getBalance(){
        return balance;
    }
    //sets the private name to a string
    public void setName(String name){
        this.name=name;
    }
    //this method reads the private var name and returns it
    public String getName(){
        return name;
    }
    public double withdraw(double withdrawAmount){
        if((balance - withdrawAmount) < 0){
            System.out.print("Not enough funds. \n");
            return 0;
        }
        else{
             return (balance-= withdrawAmount);
        }
    }

    
}

