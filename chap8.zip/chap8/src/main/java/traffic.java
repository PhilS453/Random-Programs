/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author phils
 */
public enum traffic {
    Red("Red is 5 seconds"),
    Yellow("Yellow is 3 seconds"),
    Green("Green is 6 seconds");
    private final String time;
    
    traffic(String time){
        this.time = time;
    }
    public String getLight(){
        return time;
    }
}
